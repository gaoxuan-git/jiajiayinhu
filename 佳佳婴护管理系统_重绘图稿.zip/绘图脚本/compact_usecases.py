from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, html

B = Path('/tmp/jiajia-thesis-v2')
A = B / 'figures'
roles = {
    'uc_parent': ('家长', [
        ('维护个人资料', '管理婴幼儿及健康成长档案'),
        ('浏览机构与保姆', '提交和管理服务预约'),
        ('查看护理计划与记录', '提交护理评价'),
        ('浏览商品与管理购物车', '创建和管理订单'),
        ('查看数据统计', '收发业务消息')]),
    'uc_nanny': ('保姆', [
        ('维护个人资料', '管理证书和地址'),
        ('查看排班与申请调班', '查看服务预约'),
        ('签到签退', '查看并执行护理计划'),
        ('创建和维护护理记录', '查看评价与回复'),
        ('查看联系人和会话', '收发业务消息')]),
    'uc_institution': ('机构管理员', [
        ('维护机构资料', '审核和管理保姆档案'),
        ('创建排班与审批调班', '确认预约与分配保姆'),
        ('制定和管理护理计划', '查询护理与健康记录'),
        ('查看服务评价', '管理商品、库存和订单'),
        ('查看经营统计与导出报表', '收发业务消息')]),
    'uc_admin': ('系统管理员', [
        ('管理平台账号', '管理家长与婴幼儿'),
        ('审核并管理机构', '管理保姆资料'),
        ('维护商品分类与商品', '发布和管理平台公告'),
        ('查询健康档案', '查看平台统计与导出报表'),
        ('管理联系人与会话', '收发平台消息')])
}
font = ImageFont.truetype('/System/Library/Fonts/Supplemental/Songti.ttc', 32)
titlefont = ImageFont.truetype('/System/Library/Fonts/Supplemental/Songti.ttc', 36)
for key, (role, groups) in roles.items():
    image = Image.new('RGB', (1300, 1000), 'white')
    draw = ImageDraw.Draw(image)
    svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="1300" height="1000" viewBox="0 0 1300 1000"><rect width="100%" height="100%" fill="white"/>']
    def line(x1,y1,x2,y2,width=3):
        draw.line((x1,y1,x2,y2), fill='black', width=width)
        svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="black" stroke-width="{width}"/>')
    def label(x,y,t,f=font):
        draw.text((x,y),t,font=f,fill='black',anchor='mm')
        svg.append(f'<text x="{x}" y="{y+11}" text-anchor="middle" font-size="{f.size}" font-family="Songti SC,SimSun,serif">{html.escape(t)}</text>')
    draw.rectangle((390,40,1260,960),outline='black',width=3)
    svg.append('<rect x="390" y="40" width="870" height="920" fill="none" stroke="black" stroke-width="3"/>')
    label(825,85,'佳佳婴护管理系统',titlefont)
    draw.ellipse((155,380,215,440),outline='black',width=3)
    svg.append('<circle cx="185" cy="410" r="30" fill="none" stroke="black" stroke-width="3"/>')
    line(185,440,185,550); line(130,480,240,480); line(185,550,140,620); line(185,550,230,620)
    label(185,675,role)
    for i,(a,b) in enumerate(groups):
        y=185+i*172
        line(240,480,510,y,2)
        draw.ellipse((510,y-65,1200,y+65),fill='white',outline='black',width=3)
        svg.append(f'<ellipse cx="855" cy="{y}" rx="345" ry="65" fill="white" stroke="black" stroke-width="3"/>')
        label(855,y-20,a); label(855,y+22,b)
    svg.append('</svg>')
    image.save(A/(key+'.png'))
    (A/(key+'.svg')).write_text('\n'.join(svg))
    # Preserve editable UML semantics, with matching grouped use cases.
    uml = ['@startuml','left to right direction','skinparam defaultFontName "Songti SC"',
           'skinparam defaultFontSize 18','skinparam shadowing false','skinparam backgroundColor white',
           'skinparam usecaseBackgroundColor white','skinparam usecaseBorderColor black',
           f'actor "{role}" as user','rectangle "佳佳婴护管理系统" {']
    for i,(a,b) in enumerate(groups):
        uml.append(f' usecase "{a}\\n{b}" as c{i}')
    uml.append('}')
    uml.extend(f'user -- c{i}' for i in range(len(groups)))
    uml.append('@enduml')
    (A/(key+'.puml')).write_text('\n'.join(uml))
manifest=json.loads((B/'figures.json').read_text())
for item in manifest:
    if item['key'] in roles:
        item['width'],item['height']=1300,1000
(B/'figures.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('Updated four use case diagrams for document readability.')
