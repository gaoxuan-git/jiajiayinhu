from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import json, math, html, subprocess, shutil, re

B = Path('/tmp/jiajia-thesis-v2')
A = B / 'figures'
A.mkdir(exist_ok=True)
schema = json.loads((B / 'schema.json').read_text())
font_path = '/System/Library/Fonts/Supplemental/Songti.ttc'
if not Path(font_path).exists():
    font_path = '/System/Library/Fonts/STHeiti Light.ttc'
manifest = []
def register(key, caption, kind):
    manifest.append({'key': key, 'caption': caption, 'kind': kind, 'path': str(A / (key + '.png'))})
def puml(key, caption, content, kind='uml'):
    skin = '''@startuml
skinparam defaultFontName "Songti SC"
skinparam defaultFontSize 18
skinparam dpi 180
skinparam shadowing false
skinparam backgroundColor white
skinparam ArrowColor #8B0000
skinparam conditionStyle diamond
skinparam ConditionEndStyle hline
skinparam activity {
 BackgroundColor #FFFACD
 BorderColor #8B0000
 FontColor black
 DiamondBackgroundColor #FFFACD
 DiamondBorderColor #8B0000
 StartColor #8B0000
 EndColor #8B0000
}
skinparam swimlane {
 TitleBackgroundColor #C8C8C8
 TitleFontColor black
 BorderColor #8B0000
}
skinparam sequence {
 ActorBackgroundColor #FFF8DC
 ActorBorderColor #8B4513
 ParticipantBackgroundColor #FFFACD
 ParticipantBorderColor #8B4513
 EntityBackgroundColor #FFFACD
 EntityBorderColor #8B4513
 ArrowColor #8B4513
 LifeLineBorderColor #8B4513
 LifeLineBackgroundColor #FFFACD
}
skinparam usecase {
 BackgroundColor white
 BorderColor black
}
skinparam actor {
 BorderColor black
}
skinparam rectangle {
 BackgroundColor white
 BorderColor black
}
'''
    (A / (key + '.puml')).write_text(skin + content + '\n@enduml\n')
    register(key, caption, kind)
def dot(key, caption, content):
    (A / (key + '.dot')).write_text(content)
    register(key, caption, 'structure')

roles = [
 ('uc_parent','家长功能用例图','家长',['维护个人资料','管理婴幼儿档案','查看健康与成长记录','浏览机构和保姆','提交与管理预约','查看护理计划与记录','提交护理评价','浏览商品与管理购物车','管理订单','查看统计与收发消息']),
 ('uc_nanny','保姆功能用例图','保姆',['维护资料和证书','查看排班与申请调班','查看服务预约','签到与签退','查看并执行护理计划','填写护理记录','查看评价与回复','收发业务消息']),
 ('uc_institution','机构管理员功能用例图','机构管理员',['维护机构资料','管理保姆档案','创建排班与审批调班','确认预约与分配保姆','制定护理计划','查询护理与健康记录','查看服务评价','管理商品、库存与订单','查看经营统计','收发业务消息']),
 ('uc_admin','系统管理员功能用例图','系统管理员',['管理平台账号','管理家长与婴幼儿','审核并管理机构','管理保姆资料','维护商品分类与商品','发布平台公告','查询健康档案','查看平台统计与导出报表','收发平台消息'])
]
for key, cap, role, uses in roles:
    code = f'left to right direction\nactor "{role}" as u\nrectangle "佳佳婴护管理系统" {{\n'
    for i, t in enumerate(uses):
        code += f' usecase "{t}" as c{i}\n'
    code += '}\n'
    for i in range(len(uses)):
        code += f'u -- c{i}\n'
    puml(key, cap, code, 'usecase')
dot('architecture','系统总体架构图','''digraph G {
graph [rankdir=TB,bgcolor="white",nodesep=0.3,ranksep=0.5];
node [shape=box,fontname="Songti SC",fontsize=22,color="black",style="solid",margin="0.2,0.12"];
edge [color="black",arrowsize=0.7];
v [label="表现层：Vue.js\\n家长端｜保姆端｜机构端｜管理员端"];
c [label="接口层：Spring Boot\\n身份验证｜参数校验｜统一响应"];
s [label="业务层\\n预约｜排班｜护理｜商城｜消息｜统计"];
m [label="数据访问层：MyBatis-Plus\\n对象映射｜条件查询｜分页访问"];
d [label="MySQL\\n业务数据持久化"];
r [label="Redis\\n会话与缓存"];
v -> c [label=" RESTful API",fontname="Times New Roman",fontsize=16];
c -> s; s -> m; m -> d; s -> r;
}''')
dot('modules','系统功能层次图','''digraph G {
graph [rankdir=LR,bgcolor="white",nodesep=0.3,ranksep=0.5];
node [shape=box,fontname="Songti SC",fontsize=22,color="black",margin="0.15,0.12"];
edge [dir=none,color="black"];
root [label="佳佳婴护\\n管理系统"];
p [label="家长子系统"];n [label="保姆子系统"];i [label="机构子系统"];a [label="管理员子系统"];
pp [label="婴幼儿与健康档案\\n机构浏览与服务预约\\n护理记录与评价\\n商城、订单及消息"];
nn [label="排班与调班申请\\n预约与签到签退\\n护理计划与记录\\n评价与消息"];
ii [label="机构与保姆档案\\n排班、派单与计划\\n护理监督与经营管理\\n统计与消息"];
aa [label="账号、机构与人员\\n商品分类、商品及公告\\n档案查询与平台统计\\n报表与消息"];
root -> p;root -> n;root -> i;root -> a;p -> pp;n -> nn;i -> ii;a -> aa;
}''')

puml('activity_parent','家长服务预约活动图','''start
:家长登录并选择婴幼儿档案;
:浏览机构、保姆及可预约时段;
:填写服务类型、地址和护理需求;
while (信息完整且时段可用？) is (否)
 :查看提示并修改预约信息;
endwhile (是)
:提交预约，生成待确认记录;
if (机构是否确认预约？) then (确认)
 :接收预约确认与服务安排;
 :查看护理计划及执行记录;
 :服务结束后提交评价;
else (取消)
 :查看取消原因并重新选择服务;
endif
stop''','activity')
puml('swimlane_booking','家长预约与机构派单泳道图','''|家长|
start
:选择婴幼儿、机构和服务时段;
:填写服务地址与需求;
|佳佳婴护管理系统|
while (预约信息和时段校验通过？) is (否)
 |家长|
 :根据提示补充或修改信息;
 |佳佳婴护管理系统|
endwhile (是)
:生成待确认预约;
|机构管理员|
:查看预约需求与人员排班;
if (是否能够安排服务？) then (是)
 :确认预约并分配保姆;
 |佳佳婴护管理系统|
 :保存安排并向相关用户展示;
 |保姆|
 :查看预约和护理要求;
 |家长|
 :查看预约确认结果;
else (否)
 |机构管理员|
 :取消预约并填写原因;
 |家长|
 :查看结果并调整服务选择;
endif
stop''','swimlane')
puml('seq_booking','护理服务预约业务时序图','''actor 家长 as P
participant 预约管理 as S
participant 预约单 as A
actor 机构管理员 as I
actor 保姆 as N
P -> S : 提交服务对象、时段及护理需求
activate S
S -> S : 校验资料、权限和可预约时段
alt 信息或时段不符合要求
 S --> P : 返回原因，提示修改
else 校验通过
 S -> A : 创建待确认预约单
 S --> P : 返回预约单号与待确认状态
 I -> S : 查看预约需求和可分配人员
 S --> I : 返回预约单及排班信息
 alt 能够安排服务
  I -> S : 确认预约并分配保姆
  S -> A : 保存确认状态和责任保姆
  S --> N : 展示服务安排
  S --> P : 展示预约确认结果
 else 无法安排服务
  I -> S : 提交取消原因
  S -> A : 保存取消状态
  S --> P : 返回取消结果与原因
 end
end
deactivate S''')
puml('seq_mall','商城订单业务时序图','''actor 家长 as P
participant 商城管理 as S
participant 购物车 as C
participant 订单 as O
participant 商品库存 as K
actor 机构管理员 as I
P -> S : 浏览商品并加入购物车
S -> C : 保存商品和选购数量
P -> S : 提交选中商品及收货信息
activate S
S -> K : 核对商品状态、价格和库存
alt 库存不足或商品不可售
 S --> P : 提示调整购买内容
else 允许下单
 S -> O : 保存订单及商品明细
 S -> K : 更新相应库存
 S -> C : 移除已结算购物车项
 S --> P : 返回订单编号与应付金额
 P -> S : 提交支付操作
 S -> O : 更新支付信息与订单状态
 I -> S : 维护发货及物流信息
 S -> O : 保存发货状态
 P -> S : 确认收货
 S -> O : 更新订单为已完成
end
deactivate S''')
puml('activity_nanny','保姆护理服务活动图','''start
:保姆登录并查看当日预约;
:核对婴幼儿信息和服务要求;
if (预约是否已分配且可服务？) then (是)
 :到达服务地点并提交签到信息;
 if (签到校验是否通过？) then (是)
  :查看并执行护理计划;
  :填写护理类型、内容和图片;
  :提交护理记录并核对结果;
  :服务结束后签退;
  :查看家长评价并回复;
 else (否)
  :查看异常原因并联系机构处理;
 endif
else (否)
 :查看当前预约状态;
endif
stop''','activity')
puml('seq_record','护理记录创建业务时序图','''actor 保姆 as N
participant 护理管理 as S
participant 护理计划 as P
participant 护理记录 as R
actor 家长 as F
N -> S : 请求查看已分配的护理计划
S -> P : 查询计划内容和执行状态
S --> N : 返回服务对象与护理任务
N -> S : 提交护理类型、内容、图片和备注
activate S
S -> S : 核对任务权限、签到状态及必填项
alt 条件不满足
 S --> N : 返回提示并要求修正
else 允许保存
 S -> R : 创建护理记录并关联婴幼儿和计划
 S --> N : 返回保存结果
 F -> S : 查询婴幼儿或计划下的护理记录
 S -> R : 获取授权范围内的记录
 S --> F : 返回护理详情与时间信息
end
deactivate S''')
puml('seq_checkin','签到签退业务时序图','''actor 保姆 as N
participant 考勤管理 as S
participant 预约单 as A
participant 签到记录 as R
N -> S : 提交预约编号和签到位置
activate S
S -> A : 核对责任保姆和预约状态
S -> S : 校验位置与重复签到情况
alt 不符合签到条件
 S --> N : 返回异常提示
else 满足签到条件
 S -> R : 保存签到时间、位置及备注
 S --> N : 返回签到成功结果
 N -> S : 服务结束后提交签退
 S -> R : 查验已有签到并保存签退信息
 S --> N : 返回签退结果
end
deactivate S''')
puml('activity_institution','机构服务管理活动图','''start
:机构管理员登录管理端;
:查看预约、排班及护理待办;
if (选择预约处理？) then (是)
 :核对服务需求和可用人员;
 if (能够安排服务？) then (是)
  :确认预约并分配责任保姆;
  :制定护理计划并下发任务;
 else (否)
  :取消预约并说明原因;
 endif
else (排班或计划管理)
 :维护排班或护理计划;
 if (存在时间冲突？) then (是)
  :调整人员和服务时段;
 else (否)
  :保存安排;
 endif
endif
:检查护理记录、评价及运营数据;
stop''','activity')
puml('seq_schedule','排班创建与调班审批业务时序图','''actor 机构管理员 as I
participant 排班管理 as S
participant 排班记录 as R
actor 保姆 as N
I -> S : 提交人员、日期和班次
activate S
S -> R : 检查现有排班与时间冲突
alt 存在冲突
 S --> I : 提示调整排班
else 排班可用
 S -> R : 保存排班信息
 S --> N : 展示个人排班
end
N -> S : 提交调班目标及原因
S -> R : 保存待处理调班信息
I -> S : 查看调班申请并作出审批
alt 同意调班
 S -> R : 核对冲突并更新相关排班
 S --> N : 返回调班结果及新安排
else 不同意调班
 S --> N : 返回处理意见，保留原安排
end
deactivate S''')
puml('seq_plan','护理计划制定与执行业务时序图','''actor 机构管理员 as I
participant 护理计划管理 as S
participant 护理计划 as P
actor 保姆 as N
actor 家长 as F
I -> S : 根据预约填写计划内容和起止日期
activate S
S -> S : 核对机构、婴幼儿和责任人员
S -> P : 保存计划并分配执行保姆
S --> I : 返回计划创建结果
N -> S : 查询已分配计划
S -> P : 获取任务内容及当前状态
S --> N : 返回护理要求与服务周期
N -> S : 按要求执行任务并提交记录
S -> P : 维护计划执行状态
F -> S : 请求查看计划及执行情况
S -> P : 查询家长授权范围内的计划
S --> F : 返回计划内容和执行记录
deactivate S''')
puml('activity_admin','管理员平台管理活动图','''start
:管理员登录佳佳婴护管理系统;
:选择账号、机构、商品或公告管理;
:查询目标数据并查看详情;
if (资料及操作是否符合要求？) then (是)
 :维护资料、调整状态或发布内容;
 :系统保存结果并更新关联展示;
else (否)
 :提示补充资料或修正操作;
endif
:查看平台统计及业务报表;
if (是否需要导出报表？) then (是)
 :选择时间和统计条件;
 :生成并下载报表文件;
else (否)
 :浏览统计结果;
endif
stop''','activity')
puml('seq_users','用户管理业务时序图','''actor 系统管理员 as A
participant 用户管理 as S
participant 用户档案 as U
A -> S : 选择用户类型并提交查询条件
activate S
S -> U : 查询账号资料和当前状态
S --> A : 返回用户列表与详情
A -> S : 提交资料修改、启停用或删除操作
S -> S : 校验管理权限和操作条件
alt 操作符合要求
 S -> U : 保存资料或更新账号状态
 S --> A : 返回处理结果并刷新列表
else 操作不符合要求
 S --> A : 返回原因，保留原有资料
end
deactivate S''')
puml('seq_reports','数据统计与报表业务时序图','''actor 系统管理员 as A
participant 统计报表管理 as S
participant 业务统计数据 as D
participant 报表文件 as F
A -> S : 查询平台仪表盘
activate S
S -> D : 汇总用户、机构、订单及收入
S --> A : 返回统计指标与图表数据
A -> S : 选择报表类型和时间范围
S -> S : 校验访问权限和统计条件
S -> D : 获取指定范围内的业务记录
S -> F : 生成报表内容
S --> A : 返回报表下载结果
deactivate S''')

entity_names = {
 'sys_user':'系统管理员','parent':'家长','institution':'护理机构','nanny':'保姆','baby':'婴幼儿',
 'baby_health_record':'健康档案','baby_growth_record':'成长记录','appointment':'服务预约',
 'nanny_schedule':'保姆排班','care_plan':'护理计划','care_record':'护理记录','care_plan_checkin':'签到记录',
 'care_evaluation':'护理评价','product_category':'商品分类','product':'商品','cart':'购物车',
 'orders':'订单','order_item':'订单明细'
}
def attr_label(c):
    f=c['field']
    labels={'id':'编号','password':'密码摘要','avatar':'头像','id_card':'身份证号','deleted':'删除标志',
            'status':'状态','logo':'机构标志','images':'图片集合','certificate':'资格证书',
            'cover_img':'封面图片','product_img':'商品图片','parent_id':'家长编号','nanny_id':'保姆编号',
            'baby_id':'婴幼儿编号','institution_id':'机构编号','care_plan_id':'计划编号','care_record_id':'记录编号',
            'appointment_id':'预约编号','category_id':'分类编号','product_id':'商品编号','order_id':'订单编号',
            'swap_target_nanny_id':'调班目标保姆','is_in_range':'位置有效标志','recorder_id':'记录人编号'}
    return labels.get(f,re.split(r'[（(]',c['comment'])[0].replace('URL','').replace('ID','编号').replace('JSON数组','图片').strip() or f)
def entity(key,name,cols):
    width,height=1700,940
    im=Image.new('RGB',(width,height),'white');draw=ImageDraw.Draw(im)
    svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}"><rect width="100%" height="100%" fill="white"/>']
    cx,cy=850,470;rw,rh=320,100;rx,ry=112,38
    n=len(cols);side=min(4,max(1,n//5));left=side;right=side;top=math.ceil((n-left-right)/2);bottom=n-left-right-top
    positions=[]
    for k,count in [('top',top),('right',right),('bottom',bottom),('left',left)]:
        for j in range(count):
            if k in ('top','bottom'):
                x=160+(1380*(j+0.5)/count);y=90 if k=='top' else 850
                tx=cx+(j-(count-1)/2)*min(45,270/max(1,count-1));ty=cy-rh/2 if k=='top' else cy+rh/2
                end=(x,y+ry if k=='top' else y-ry)
            else:
                x=125 if k=='left' else 1575;y=210+520*(j+0.5)/count
                tx=cx-rw/2 if k=='left' else cx+rw/2;ty=cy+(j-(count-1)/2)*min(25,80/max(1,count-1))
                end=(x+rx if k=='left' else x-rx,y)
            positions.append((x,y,tx,ty,end))
    for c,(x,y,tx,ty,end) in zip(cols,positions):
        draw.line((tx,ty,*end),fill='black',width=2)
        svg.append(f'<line x1="{tx}" y1="{ty}" x2="{end[0]}" y2="{end[1]}" stroke="black" stroke-width="2"/>')
    draw.rectangle((cx-rw/2,cy-rh/2,cx+rw/2,cy+rh/2),fill='white',outline='black',width=3)
    svg.append(f'<rect x="{cx-rw/2}" y="{cy-rh/2}" width="{rw}" height="{rh}" fill="white" stroke="black" stroke-width="3"/>')
    fn=ImageFont.truetype(font_path,38);draw.text((cx,cy),name,font=fn,fill='black',anchor='mm')
    svg.append(f'<text x="{cx}" y="{cy+12}" text-anchor="middle" font-family="Songti SC,SimSun,serif" font-size="38">{name}</text>')
    for c,(x,y,*_) in zip(cols,positions):
        draw.ellipse((x-rx,y-ry,x+rx,y+ry),fill='white',outline='black',width=2)
        label=attr_label(c);size=28
        ft=ImageFont.truetype(font_path,size)
        while draw.textlength(label,font=ft)>rx*1.8 and size>18:size-=1;ft=ImageFont.truetype(font_path,size)
        draw.text((x,y),label,font=ft,fill='black',anchor='mm')
        svg.append(f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="white" stroke="black" stroke-width="2"/><text x="{x}" y="{y+size*0.33}" text-anchor="middle" font-family="Songti SC,SimSun,serif" font-size="{size}">{html.escape(label)}</text>')
        if c['field']=='id':
            tw=draw.textlength(label,font=ft);draw.line((x-tw/2,y+18,x+tw/2,y+18),fill='black',width=2)
            svg.append(f'<line x1="{x-tw/2}" y1="{y+18}" x2="{x+tw/2}" y2="{y+18}" stroke="black" stroke-width="2"/>')
    svg.append('</svg>')
    im.save(A/(key+'.png'),dpi=(300,300))
    (A/(key+'.svg')).write_text('\n'.join(svg))
    register(key,name+'实体属性图','entity')
for table,name in entity_names.items():
    entity('entity_'+table,name,schema[table])

def er(key, caption, relations):
    names={a for r in relations for a in [r[0],r[2]]}
    code='graph G {\ngraph [rankdir=LR,bgcolor="white",nodesep=0.5,ranksep=0.5,overlap=false,splines=polyline];\nnode [shape=box,fontname="Songti SC",fontsize=22,color=black,margin="0.15,0.12"];\nedge [fontname="Times New Roman",fontsize=18,color=black,dir=none];\n'
    for n in names:code+=f'{n} [label="{entity_names[n]}"];\n'
    for j,(a,verb,b,ca,cb) in enumerate(relations):
        code+=f'r{j} [shape=diamond,label="{verb}",width=1.0,height=0.6,fontsize=18];\n{a} -- r{j} [taillabel="{ca}",labeldistance=1.8];\nr{j} -- {b} [headlabel="{cb}",labeldistance=1.8];\n'
    code+='}'
    dot(key,caption,code)
er('er_profiles','用户与婴幼儿档案E-R图',[
 ('parent','监护','baby','1','N'),('institution','所属','nanny','1','N'),
 ('baby','记录','baby_health_record','1','N'),('baby','记录','baby_growth_record','1','N')])
er('er_booking','服务预约与计划E-R图',[
 ('parent','提交','appointment','1','N'),('baby','对应','appointment','1','N'),
 ('institution','受理','appointment','1','N'),('nanny','承担','appointment','1','N'),
 ('appointment','关联','care_plan','1','N')])
er('er_execution','护理执行与签到E-R图',[
 ('care_plan','形成','care_record','1','N'),('nanny','执行','care_record','1','N'),
 ('baby','对应','care_record','1','N'),('appointment','记录','care_plan_checkin','1','N')])
er('er_schedule_review','排班与服务评价E-R图',[
 ('institution','制定','nanny_schedule','1','N'),('nanny','对应','nanny_schedule','1','N'),
 ('parent','填写','care_evaluation','1','N'),('nanny','获得','care_evaluation','1','N')])
er('er_shop','商城交易业务E-R图',[
 ('institution','发布','product','1','N'),('product_category','归类','product','1','N'),
 ('parent','创建','orders','1','N'),('orders','包含','order_item','1','N'),
 ('product','对应','order_item','1','N'),('parent','选购','cart','1','N'),('product','加入','cart','1','N')])

java = next(B.glob('jdk-*/Contents/Home/bin/java'))
log = B/'drawing-render.log'
with log.open('w') as f:
    result = subprocess.run([str(java),'-Djava.awt.headless=true','-jar',str(B/'plantuml.jar'),'-charset','UTF-8','-tpng',str(A/'*.puml')],stdout=f,stderr=f)
    if result.returncode:raise RuntimeError('PlantUML failed; inspect '+str(log))
    result = subprocess.run([str(java),'-Djava.awt.headless=true','-jar',str(B/'plantuml.jar'),'-charset','UTF-8','-tsvg',str(A/'*.puml')],stdout=f,stderr=f)
    if result.returncode:raise RuntimeError('PlantUML SVG failed; inspect '+str(log))
    for source in A.glob('*.dot'):
        for fmt in ['png','svg']:
            args=['dot','-T'+fmt,str(source),'-o',str(source.with_suffix('.'+fmt))]
            if fmt=='png':args.insert(1,'-Gdpi=180')
            result=subprocess.run(args,stdout=f,stderr=f)
            if result.returncode:raise RuntimeError('Graphviz failed; inspect '+str(log))
for item in manifest:
    image=Image.open(item['path'])
    item['width'],item['height']=image.size
    if image.width<150 or image.height<100:raise RuntimeError('Incomplete drawing '+item['key'])
(B/'figures.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print('Rendered',len(manifest),'figures with editable source and SVG exports.')
