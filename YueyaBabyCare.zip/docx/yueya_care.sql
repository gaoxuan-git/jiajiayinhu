/*
 Navicat Premium Dump SQL

 Source Server         : mydatabse
 Source Server Type    : MySQL
 Source Server Version : 80026 (8.0.26)
 Source Host           : localhost:3306
 Source Schema         : yueya_care

 Target Server Type    : MySQL
 Target Server Version : 80026 (8.0.26)
 File Encoding         : 65001

 Date: 25/12/2025 23:19:22
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `relation_type` tinyint NOT NULL COMMENT '关联人类型（1-家长，2-保姆，3-机构）',
  `relation_id` bigint NOT NULL COMMENT '关联人ID',
  `province` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '省份',
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '城市',
  `district` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '区县',
  `detail_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '详细地址',
  `longitude` decimal(10, 7) NULL DEFAULT NULL COMMENT '经度',
  `latitude` decimal(10, 7) NULL DEFAULT NULL COMMENT '纬度',
  `is_default` tinyint NULL DEFAULT 0 COMMENT '是否默认地址（0-否，1-是）',
  `contact_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系人姓名',
  `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_relation`(`relation_type` ASC, `relation_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '地址表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of address
-- ----------------------------
INSERT INTO `address` VALUES (1, 1, 1, '北京市', '北京市', '朝阳区', '建国路88号SOHO现代城A座1501室', 116.4716000, 39.9088000, 0, '张伟', '13800138001', '2025-01-15 10:40:00', '2025-12-25 23:01:48', 0);
INSERT INTO `address` VALUES (2, 1, 1, '北京市', '北京市', '海淀区', '中关村大街1号海龙大厦B座802室', 116.3184000, 39.9836000, 0, '张伟', '13800138001', '2025-01-20 14:00:00', '2025-12-23 19:37:49', 0);
INSERT INTO `address` VALUES (3, 1, 2, '上海市', '上海市', '浦东新区', '陆家嘴环路1000号恒生银行大厦2201室', 121.5055000, 31.2362000, 1, '李娜', '13800138002', '2025-02-20 14:30:00', '2025-12-23 19:37:49', 0);
INSERT INTO `address` VALUES (4, 1, 3, '广东省', '广州市', '天河区', '天河路385号太古汇一座3305室', 113.3245000, 23.1291000, 1, '王芳', '13800138003', '2025-03-10 09:25:00', '2025-12-23 19:37:49', 0);
INSERT INTO `address` VALUES (5, 1, 4, '广东省', '深圳市', '南山区', '科技园南区深南大道9966号威盛科技大厦1808室', 113.9436000, 22.5329000, 1, '刘洋', '13800138004', '2025-04-05 16:55:00', '2025-12-23 19:37:49', 0);
INSERT INTO `address` VALUES (6, 1, 5, '浙江省', '杭州市', '西湖区', '文三路478号华星时代广场A座1206室', 120.1301000, 30.2741000, 1, '陈霞', '13800138005', '2025-05-18 11:40:00', '2025-12-23 19:37:49', 0);
INSERT INTO `address` VALUES (7, 1, 6, '四川省', '成都市', '武侯区', '人民南路四段1号时代广场B座2501室', 104.0668000, 30.6544000, 1, '赵明', '13800138006', '2025-06-22 08:10:00', '2025-12-23 19:37:49', 0);
INSERT INTO `address` VALUES (8, 1, 7, '江苏省', '南京市', '鼓楼区', '中山北路30号城市名人酒店公寓1102室', 118.7674000, 32.0603000, 1, '孙丽', '13800138007', '2025-07-08 13:30:00', '2025-12-23 19:37:49', 0);
INSERT INTO `address` VALUES (9, 1, 8, '湖北省', '武汉市', '江汉区', '解放大道688号武汉广场写字楼1905室', 114.2793000, 30.5844000, 1, '周军', '13800138008', '2025-08-12 15:50:00', '2025-12-23 19:37:49', 0);
INSERT INTO `address` VALUES (10, 1, 1, '湖南省', '长沙市', '开福区', '新河街道幸福桥社区卫生服务站天健城北区', 112.9844910, 28.2239420, 1, '张三', '15743600767', '2025-12-24 21:07:10', '2025-12-25 23:01:34', 1);
INSERT INTO `address` VALUES (11, 3, 1, '吉林省', '长春市', '德惠市', '胜利街道德惠市人民政府', 125.7285520, 44.5217880, 1, '张三', '15643600767', '2025-12-25 23:00:17', '2025-12-25 23:00:45', 1);
INSERT INTO `address` VALUES (12, 3, 1, '吉林省', '长春市', '德惠市', '胜利街道德惠市人民政府', 125.7285520, 44.5217880, 1, '张三', '15643600767', '2025-12-25 23:01:16', '2025-12-25 23:01:16', 0);
INSERT INTO `address` VALUES (13, 1, 1, '湖南省', '长沙市', '开福区', '新河街道幸福桥社区卫生服务站天健城北区', 112.9844910, 28.2239420, 1, '张三', '15743600767', '2025-12-25 23:01:49', '2025-12-25 23:01:49', 0);

-- ----------------------------
-- Table structure for appointment
-- ----------------------------
DROP TABLE IF EXISTS `appointment`;
CREATE TABLE `appointment`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `appointment_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '预约单号',
  `parent_id` bigint NOT NULL COMMENT '家长ID',
  `baby_id` bigint NOT NULL COMMENT '宝宝ID',
  `institution_id` bigint NOT NULL COMMENT '机构ID',
  `nanny_id` bigint NULL DEFAULT NULL COMMENT '指定保姆ID',
  `service_type` tinyint NULL DEFAULT 1 COMMENT '服务类型（1-日常护理，2-月嫂服务，3-育儿指导，4-其他）',
  `appointment_date` date NOT NULL COMMENT '预约日期',
  `start_time` time NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` time NULL DEFAULT NULL COMMENT '结束时间',
  `requirement` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '服务需求',
  `address_id` bigint NULL DEFAULT NULL COMMENT '服务地址ID',
  `status` tinyint NULL DEFAULT 0 COMMENT '状态（0-待确认，1-已确认，2-进行中，3-已完成，4-已取消）',
  `cancel_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '取消原因',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_appointment_no`(`appointment_no` ASC) USING BTREE,
  INDEX `idx_parent_id`(`parent_id` ASC) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE,
  INDEX `idx_nanny_id`(`nanny_id` ASC) USING BTREE,
  INDEX `idx_appointment_date`(`appointment_date` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '预约表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of appointment
-- ----------------------------
INSERT INTO `appointment` VALUES (2, 'YY202512232158018366', 1, 2, 1, 1, 1, '2025-12-23', '10:00:00', '16:00:00', '111', 2, 2, NULL, '2025-12-23 21:58:01', '2025-12-24 20:07:56', 0);
INSERT INTO `appointment` VALUES (3, 'YY202512242107386689', 1, 1, 1, 1, 1, '2025-12-26', '07:00:00', '20:00:00', '1111', 10, 2, NULL, '2025-12-24 21:07:39', '2025-12-24 21:09:12', 0);
INSERT INTO `appointment` VALUES (4, 'YY202512252239551502', 1, 2, 1, 1, 1, '2025-12-25', '23:00:00', '23:30:00', '细节一点', 10, 3, NULL, '2025-12-25 22:39:56', '2025-12-25 22:44:38', 0);
INSERT INTO `appointment` VALUES (5, 'YY202512252302324396', 1, 2, 1, 1, 1, '2025-12-25', '07:00:00', '17:00:00', '111111111111', 1, 2, NULL, '2025-12-25 23:02:33', '2025-12-25 23:03:14', 0);

-- ----------------------------
-- Table structure for baby
-- ----------------------------
DROP TABLE IF EXISTS `baby`;
CREATE TABLE `baby`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `parent_id` bigint NOT NULL COMMENT '家长ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '宝宝姓名',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宝宝昵称',
  `gender` tinyint NULL DEFAULT 0 COMMENT '性别（0-未知，1-男，2-女）',
  `birth_date` date NOT NULL COMMENT '出生日期',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '宝宝头像',
  `blood_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '血型',
  `allergy_info` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '过敏信息',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_parent_id`(`parent_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '婴幼儿信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baby
-- ----------------------------
INSERT INTO `baby` VALUES (1, 1, '张小明', '明明', 1, '2024-03-15', 'https://img.zcool.cn/community/01e7c85cd5c757a80120a895f78c0c.jpg', 'A', NULL, '活泼好动，喜欢听音乐', '2025-01-15 10:35:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (2, 1, '张小美', '美美', 2, '2025-06-20', '/upload/2025/12/24/fa00f44b9cfb451da446fbc9a46bc46c.jpg', 'A', '花生过敏', '刚出生不久，需要特别照顾', '2025-06-25 09:00:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (3, 2, '王子轩', '轩轩', 1, '2023-11-08', 'https://img.zcool.cn/community/01c0a85cd5c759a80120a895d8e8e8.jpg', 'B', NULL, '喜欢玩积木，对颜色敏感', '2025-02-20 14:25:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (4, 3, '李思琪', '琪琪', 2, '2024-07-22', 'https://img.zcool.cn/community/01d8f85cd5c75aa80120a8958c9c9c.jpg', 'O', '牛奶蛋白过敏', '需要喝特殊配方奶粉', '2025-03-10 09:20:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (5, 3, '李思远', '远远', 1, '2024-07-22', 'https://img.zcool.cn/community/01e9a85cd5c75ba80120a895a7a7a7.jpg', 'O', NULL, '双胞胎弟弟，比较安静', '2025-03-10 09:20:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (6, 4, '刘雨萱', '萱萱', 2, '2024-01-10', 'https://img.zcool.cn/community/01fab85cd5c75ca80120a895b6b6b6.jpg', 'AB', NULL, '爱笑，睡眠质量好', '2025-04-05 16:50:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (7, 5, '陈浩然', '然然', 1, '2023-09-05', 'https://img.zcool.cn/community/010bc85cd5c75da80120a895c5c5c5.jpg', 'A', '海鲜过敏', '好奇心强，喜欢探索', '2025-05-18 11:35:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (8, 6, '赵欣怡', '怡怡', 2, '2024-05-18', 'https://img.zcool.cn/community/011cd85cd5c75ea80120a895d4d4d4.jpg', 'B', NULL, '喜欢听故事，爱看绘本', '2025-06-22 08:05:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (9, 7, '孙宇航', '航航', 1, '2024-09-12', 'https://img.zcool.cn/community/012de85cd5c75fa80120a895e3e3e3.jpg', 'O', '鸡蛋过敏', '精力充沛，喜欢户外活动', '2025-07-08 13:25:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (10, 7, '孙宇轩', '小轩', 1, '2025-08-01', 'https://img.zcool.cn/community/013ef85cd5c760a80120a895f2f2f2.jpg', 'O', NULL, '新生儿，需要细心呵护', '2025-08-05 10:00:00', '2025-12-23 19:37:49', 0);
INSERT INTO `baby` VALUES (11, 8, '周雅琳', '琳琳', 2, '2024-02-28', 'https://img.zcool.cn/community/014f085cd5c761a80120a8950101.jpg', 'A', NULL, '性格温和，喜欢安静', '2025-08-12 15:45:00', '2025-12-23 19:37:49', 0);

-- ----------------------------
-- Table structure for baby_growth_record
-- ----------------------------
DROP TABLE IF EXISTS `baby_growth_record`;
CREATE TABLE `baby_growth_record`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `baby_id` bigint NOT NULL COMMENT '宝宝ID',
  `record_date` date NOT NULL COMMENT '记录日期',
  `record_type` tinyint NULL DEFAULT 1 COMMENT '记录类型（1-饮食，2-睡眠，3-排便，4-活动，5-其他）',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '记录内容',
  `images` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '图片（JSON数组）',
  `recorder_type` tinyint NULL DEFAULT 1 COMMENT '记录人类型（1-家长，2-保姆）',
  `recorder_id` bigint NULL DEFAULT NULL COMMENT '记录人ID',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_baby_id`(`baby_id` ASC) USING BTREE,
  INDEX `idx_record_date`(`record_date` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '婴幼儿成长记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baby_growth_record
-- ----------------------------
INSERT INTO `baby_growth_record` VALUES (1, 2, '2025-12-23', 3, '拉臭臭', '今天拉了大臭臭', '[\"http://localhost:8080/upload/2025/12/23/8a44fe5f106c4313a0864965bd3c8b00.jpg\",\"http://localhost:8080/upload/2025/12/23/3f159f5a08a24130a73017c11bde4406.png\"]', 1, 1, '2025-12-23 20:36:29', '2025-12-23 20:36:29', 0);
INSERT INTO `baby_growth_record` VALUES (2, 2, '2025-12-18', 2, '今天宝宝睡足了八小时', '睡的很香', '[\"/upload/2025/12/25/2c8ce19124554726b03a47b8f1a5bc47.jpg\"]', 1, 1, '2025-12-25 22:38:05', '2025-12-25 22:38:05', 0);

-- ----------------------------
-- Table structure for baby_health_record
-- ----------------------------
DROP TABLE IF EXISTS `baby_health_record`;
CREATE TABLE `baby_health_record`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `baby_id` bigint NOT NULL COMMENT '宝宝ID',
  `record_date` date NOT NULL COMMENT '记录日期',
  `height` decimal(5, 2) NULL DEFAULT NULL COMMENT '身高（cm）',
  `weight` decimal(5, 2) NULL DEFAULT NULL COMMENT '体重（kg）',
  `head_circumference` decimal(5, 2) NULL DEFAULT NULL COMMENT '头围（cm）',
  `temperature` decimal(4, 2) NULL DEFAULT NULL COMMENT '体温（℃）',
  `health_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '健康状况',
  `vaccination` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '疫苗接种情况',
  `illness_record` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '疾病记录',
  `recorder_type` tinyint NULL DEFAULT 1 COMMENT '记录人类型（1-家长，2-保姆）',
  `recorder_id` bigint NULL DEFAULT NULL COMMENT '记录人ID',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_baby_id`(`baby_id` ASC) USING BTREE,
  INDEX `idx_record_date`(`record_date` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 52 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '婴幼儿健康档案表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of baby_health_record
-- ----------------------------
INSERT INTO `baby_health_record` VALUES (1, 1, '2024-03-15', 50.00, 3.45, 34.50, 36.50, '新生儿，各项指标正常', '乙肝疫苗第一针、卡介苗', NULL, 1, 1, '2024-03-15 10:00:00', '2024-03-15 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (2, 1, '2024-04-15', 54.50, 4.80, 37.00, 36.60, '发育良好，吃奶正常', '乙肝疫苗第二针', NULL, 1, 1, '2024-04-15 09:30:00', '2024-04-15 09:30:00', 0);
INSERT INTO `baby_health_record` VALUES (3, 1, '2024-06-15', 61.00, 6.20, 40.50, 36.50, '生长发育正常，开始会抬头', '脊灰疫苗第一针、百白破第一针', NULL, 1, 1, '2024-06-15 14:00:00', '2024-06-15 14:00:00', 0);
INSERT INTO `baby_health_record` VALUES (4, 1, '2024-09-15', 67.50, 8.10, 43.00, 36.70, '开始添加辅食，适应良好', '乙肝疫苗第三针、脊灰疫苗第二针', NULL, 1, 1, '2024-09-15 10:30:00', '2024-09-15 10:30:00', 0);
INSERT INTO `baby_health_record` VALUES (5, 1, '2024-12-15', 72.00, 9.50, 45.00, 36.60, '会爬行，精神状态好', '麻风疫苗、乙脑疫苗第一针', NULL, 1, 1, '2024-12-15 11:00:00', '2024-12-15 11:00:00', 0);
INSERT INTO `baby_health_record` VALUES (6, 2, '2025-06-20', 49.50, 3.20, 33.80, 36.40, '新生儿，体重略轻，需加强喂养', '乙肝疫苗第一针、卡介苗', NULL, 1, 1, '2025-06-20 08:00:00', '2025-06-20 08:00:00', 0);
INSERT INTO `baby_health_record` VALUES (7, 2, '2025-07-20', 53.00, 4.30, 36.50, 36.50, '体重增长良好', '乙肝疫苗第二针', NULL, 1, 1, '2025-07-20 10:00:00', '2025-07-20 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (8, 2, '2025-09-20', 59.50, 5.80, 39.50, 36.60, '发育正常，睡眠规律', '脊灰疫苗第一针、百白破第一针', NULL, 1, 1, '2025-09-20 09:00:00', '2025-09-20 09:00:00', 0);
INSERT INTO `baby_health_record` VALUES (9, 2, '2025-12-20', 65.00, 7.20, 42.50, 36.50, '开始尝试辅食，注意避免花生制品', '乙肝疫苗第三针、脊灰疫苗第二针', NULL, 1, 1, '2025-12-20 14:30:00', '2025-12-20 14:30:00', 0);
INSERT INTO `baby_health_record` VALUES (10, 3, '2023-11-08', 51.00, 3.60, 35.00, 36.50, '新生儿健康', '乙肝疫苗第一针、卡介苗', NULL, 1, 2, '2023-11-08 11:00:00', '2023-11-08 11:00:00', 0);
INSERT INTO `baby_health_record` VALUES (11, 3, '2024-05-08', 68.00, 8.30, 43.50, 36.60, '发育良好，开始长牙', '乙肝疫苗第三针、脊灰疫苗第二针', NULL, 1, 2, '2024-05-08 10:00:00', '2024-05-08 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (12, 3, '2024-08-08', 72.50, 9.80, 45.50, 36.70, '会扶站，喜欢玩积木', '麻风疫苗、乙脑疫苗第一针', NULL, 1, 2, '2024-08-08 15:00:00', '2024-08-08 15:00:00', 0);
INSERT INTO `baby_health_record` VALUES (13, 3, '2024-11-08', 76.00, 10.50, 46.50, 36.50, '会走路，语言发育正常', 'A群流脑疫苗第一针、麻腮风疫苗', NULL, 1, 2, '2024-11-08 09:30:00', '2024-11-08 09:30:00', 0);
INSERT INTO `baby_health_record` VALUES (14, 3, '2024-12-01', 76.50, 10.40, 46.50, 37.80, '轻微感冒，流鼻涕', NULL, '普通感冒，服用小儿氨酚黄那敏颗粒，3天后痊愈', 1, 2, '2024-12-01 16:00:00', '2024-12-01 16:00:00', 0);
INSERT INTO `baby_health_record` VALUES (15, 4, '2024-07-22', 49.00, 3.10, 33.50, 36.50, '新生儿，双胞胎姐姐', '乙肝疫苗第一针、卡介苗', NULL, 1, 3, '2024-07-22 14:00:00', '2024-07-22 14:00:00', 0);
INSERT INTO `baby_health_record` VALUES (16, 4, '2024-08-22', 52.50, 4.00, 36.00, 36.60, '发现牛奶蛋白过敏，改用深度水解奶粉', '乙肝疫苗第二针', '牛奶蛋白过敏，出现湿疹和腹泻症状', 1, 3, '2024-08-22 10:30:00', '2024-08-22 10:30:00', 0);
INSERT INTO `baby_health_record` VALUES (17, 4, '2024-10-22', 58.00, 5.50, 39.00, 36.50, '过敏症状控制良好，生长追赶中', '脊灰疫苗第一针、百白破第一针', NULL, 1, 3, '2024-10-22 11:00:00', '2024-10-22 11:00:00', 0);
INSERT INTO `baby_health_record` VALUES (18, 4, '2024-12-22', 63.00, 6.80, 41.50, 36.60, '发育正常，准备添加辅食，需避免乳制品', '脊灰疫苗第二针、百白破第二针', NULL, 1, 3, '2024-12-22 09:00:00', '2024-12-22 09:00:00', 0);
INSERT INTO `baby_health_record` VALUES (19, 5, '2024-07-22', 48.50, 3.00, 33.00, 36.40, '新生儿，双胞胎弟弟，体重略轻', '乙肝疫苗第一针、卡介苗', NULL, 1, 3, '2024-07-22 14:05:00', '2024-07-22 14:05:00', 0);
INSERT INTO `baby_health_record` VALUES (20, 5, '2024-08-22', 52.00, 3.90, 35.50, 36.50, '体重增长正常', '乙肝疫苗第二针', NULL, 1, 3, '2024-08-22 10:45:00', '2024-08-22 10:45:00', 0);
INSERT INTO `baby_health_record` VALUES (21, 5, '2024-10-22', 59.00, 5.70, 39.50, 36.60, '发育良好，比较安静', '脊灰疫苗第一针、百白破第一针', NULL, 1, 3, '2024-10-22 11:15:00', '2024-10-22 11:15:00', 0);
INSERT INTO `baby_health_record` VALUES (22, 5, '2024-12-22', 64.00, 7.00, 42.00, 36.50, '生长发育正常，开始添加米粉', '脊灰疫苗第二针、百白破第二针', NULL, 1, 3, '2024-12-22 09:20:00', '2024-12-22 09:20:00', 0);
INSERT INTO `baby_health_record` VALUES (23, 6, '2024-01-10', 50.50, 3.50, 34.80, 36.50, '新生儿健康，爱笑', '乙肝疫苗第一针、卡介苗', NULL, 1, 4, '2024-01-10 09:00:00', '2024-01-10 09:00:00', 0);
INSERT INTO `baby_health_record` VALUES (24, 6, '2024-07-10', 66.50, 7.80, 42.80, 36.60, '发育良好，睡眠质量好', '乙肝疫苗第三针、脊灰疫苗第二针', NULL, 1, 4, '2024-07-10 10:00:00', '2024-07-10 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (25, 6, '2024-10-10', 71.00, 9.20, 44.80, 36.50, '会爬行，开始学站', '麻风疫苗、乙脑疫苗第一针', NULL, 1, 4, '2024-10-10 14:00:00', '2024-10-10 14:00:00', 0);
INSERT INTO `baby_health_record` VALUES (26, 6, '2024-12-10', 74.00, 9.80, 45.50, 36.60, '扶走稳定，会叫爸爸妈妈', 'A群流脑疫苗第一针', NULL, 1, 4, '2024-12-10 11:30:00', '2024-12-10 11:30:00', 0);
INSERT INTO `baby_health_record` VALUES (27, 7, '2023-09-05', 51.50, 3.70, 35.20, 36.50, '新生儿健康', '乙肝疫苗第一针、卡介苗', NULL, 1, 5, '2023-09-05 08:30:00', '2023-09-05 08:30:00', 0);
INSERT INTO `baby_health_record` VALUES (28, 7, '2024-03-05', 68.50, 8.50, 43.80, 36.60, '发育良好，好奇心强', '乙肝疫苗第三针、脊灰疫苗第二针', NULL, 1, 5, '2024-03-05 10:00:00', '2024-03-05 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (29, 7, '2024-06-15', 71.50, 9.50, 45.00, 36.80, '发现海鲜过敏，食用虾后出现皮疹', NULL, '海鲜过敏，食用虾后全身起红疹，服用抗过敏药后缓解', 1, 5, '2024-06-15 18:00:00', '2024-06-15 18:00:00', 0);
INSERT INTO `baby_health_record` VALUES (30, 7, '2024-09-05', 76.50, 10.80, 46.80, 36.50, '会独立行走，语言发育好', 'A群流脑疫苗第一针、麻腮风疫苗', NULL, 1, 5, '2024-09-05 09:00:00', '2024-09-05 09:00:00', 0);
INSERT INTO `baby_health_record` VALUES (31, 7, '2024-12-05', 79.50, 11.50, 47.50, 36.60, '发育正常，喜欢探索，注意避免海鲜', '水痘疫苗', NULL, 1, 5, '2024-12-05 14:30:00', '2024-12-05 14:30:00', 0);
INSERT INTO `baby_health_record` VALUES (32, 8, '2024-05-18', 49.80, 3.30, 34.20, 36.50, '新生儿健康', '乙肝疫苗第一针、卡介苗', NULL, 1, 6, '2024-05-18 10:00:00', '2024-05-18 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (33, 8, '2024-08-18', 60.50, 6.00, 40.00, 36.60, '发育正常，喜欢听故事', '脊灰疫苗第一针、百白破第一针', NULL, 1, 6, '2024-08-18 09:30:00', '2024-08-18 09:30:00', 0);
INSERT INTO `baby_health_record` VALUES (34, 8, '2024-11-18', 66.00, 7.60, 42.80, 36.50, '开始添加辅食，爱看绘本', '乙肝疫苗第三针、脊灰疫苗第二针', NULL, 1, 6, '2024-11-18 11:00:00', '2024-11-18 11:00:00', 0);
INSERT INTO `baby_health_record` VALUES (35, 8, '2024-12-18', 68.00, 8.00, 43.50, 36.60, '会坐稳，开始长牙', '百白破第二针', NULL, 1, 6, '2024-12-18 10:30:00', '2024-12-18 10:30:00', 0);
INSERT INTO `baby_health_record` VALUES (36, 9, '2024-09-12', 50.80, 3.55, 34.60, 36.50, '新生儿健康，精力充沛', '乙肝疫苗第一针、卡介苗', NULL, 1, 7, '2024-09-12 07:30:00', '2024-09-12 07:30:00', 0);
INSERT INTO `baby_health_record` VALUES (37, 9, '2024-10-12', 54.80, 4.90, 37.20, 36.60, '发育良好，吃奶量大', '乙肝疫苗第二针', NULL, 1, 7, '2024-10-12 10:00:00', '2024-10-12 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (38, 9, '2024-12-12', 62.00, 6.50, 41.00, 36.50, '发育正常，活泼好动，注意后续辅食添加避免鸡蛋', '脊灰疫苗第一针、百白破第一针', NULL, 1, 7, '2024-12-12 09:00:00', '2024-12-12 09:00:00', 0);
INSERT INTO `baby_health_record` VALUES (39, 10, '2025-08-01', 50.00, 3.40, 34.30, 36.50, '新生儿健康，需要细心呵护', '乙肝疫苗第一针、卡介苗', NULL, 1, 7, '2025-08-01 06:00:00', '2025-08-01 06:00:00', 0);
INSERT INTO `baby_health_record` VALUES (40, 10, '2025-09-01', 54.00, 4.60, 36.80, 36.60, '发育正常，睡眠好', '乙肝疫苗第二针', NULL, 1, 7, '2025-09-01 10:30:00', '2025-09-01 10:30:00', 0);
INSERT INTO `baby_health_record` VALUES (41, 10, '2025-11-01', 60.50, 6.10, 40.20, 36.50, '生长良好，开始会笑出声', '脊灰疫苗第一针、百白破第一针', NULL, 1, 7, '2025-11-01 09:00:00', '2025-11-01 09:00:00', 0);
INSERT INTO `baby_health_record` VALUES (42, 10, '2025-12-01', 63.00, 6.80, 41.50, 36.60, '发育正常，会翻身', '百白破第二针', NULL, 1, 7, '2025-12-01 14:00:00', '2025-12-01 14:00:00', 0);
INSERT INTO `baby_health_record` VALUES (43, 11, '2024-02-28', 49.50, 3.25, 34.00, 36.50, '新生儿健康，性格温和', '乙肝疫苗第一针、卡介苗', NULL, 1, 8, '2024-02-28 12:00:00', '2024-02-28 12:00:00', 0);
INSERT INTO `baby_health_record` VALUES (44, 11, '2024-05-28', 59.50, 5.70, 39.50, 36.60, '发育正常，喜欢安静', '脊灰疫苗第一针、百白破第一针', NULL, 1, 8, '2024-05-28 10:00:00', '2024-05-28 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (45, 11, '2024-08-28', 65.50, 7.40, 42.50, 36.50, '开始添加辅食，适应良好', '乙肝疫苗第三针、脊灰疫苗第二针', NULL, 1, 8, '2024-08-28 09:30:00', '2024-08-28 09:30:00', 0);
INSERT INTO `baby_health_record` VALUES (46, 11, '2024-11-28', 70.50, 8.90, 44.50, 36.60, '会爬行，性格依然温和', '麻风疫苗、乙脑疫苗第一针', NULL, 1, 8, '2024-11-28 11:00:00', '2024-11-28 11:00:00', 0);
INSERT INTO `baby_health_record` VALUES (47, 11, '2024-12-20', 72.00, 9.20, 45.00, 36.50, '发育良好，开始学站', NULL, NULL, 2, 1, '2024-12-20 15:00:00', '2024-12-20 15:00:00', 0);
INSERT INTO `baby_health_record` VALUES (48, 1, '2024-12-20', 72.50, 9.60, 45.20, 36.50, '精神状态好，食欲正常', NULL, NULL, 2, 1, '2024-12-20 16:00:00', '2024-12-20 16:00:00', 0);
INSERT INTO `baby_health_record` VALUES (49, 3, '2024-12-18', 77.00, 10.60, 46.80, 36.60, '活泼好动，喜欢玩积木', NULL, NULL, 2, 2, '2024-12-18 14:30:00', '2024-12-18 14:30:00', 0);
INSERT INTO `baby_health_record` VALUES (50, 6, '2024-12-15', 74.50, 9.90, 45.60, 36.50, '睡眠质量好，爱笑', NULL, NULL, 2, 3, '2024-12-15 10:00:00', '2024-12-15 10:00:00', 0);
INSERT INTO `baby_health_record` VALUES (51, 2, '2025-12-25', 34.00, 23.00, 21.00, 36.00, '健康', '以接', '没有', 1, 1, '2025-12-25 22:38:50', '2025-12-25 22:38:50', 0);

-- ----------------------------
-- Table structure for care_evaluation
-- ----------------------------
DROP TABLE IF EXISTS `care_evaluation`;
CREATE TABLE `care_evaluation`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `care_record_id` bigint NULL DEFAULT NULL COMMENT '护理记录ID',
  `care_plan_id` bigint NULL DEFAULT NULL COMMENT '护理计划ID',
  `parent_id` bigint NOT NULL COMMENT '家长ID',
  `nanny_id` bigint NOT NULL COMMENT '保姆ID',
  `score` tinyint NULL DEFAULT 5 COMMENT '评分（1-5分）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '评价内容',
  `images` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '图片（JSON数组）',
  `reply_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '回复内容',
  `reply_time` datetime NULL DEFAULT NULL COMMENT '回复时间',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_care_record_id`(`care_record_id` ASC) USING BTREE,
  INDEX `idx_parent_id`(`parent_id` ASC) USING BTREE,
  INDEX `idx_nanny_id`(`nanny_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '护理评价表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of care_evaluation
-- ----------------------------
INSERT INTO `care_evaluation` VALUES (1, NULL, 2, 1, 1, 5, '挺好不错再接再厉', NULL, '感谢', '2025-12-24 23:40:26', '2025-12-24 23:20:35', '2025-12-24 23:40:26', 0);
INSERT INTO `care_evaluation` VALUES (2, NULL, 3, 1, 1, 5, '不错不错，宝宝已经学会解微积分了', NULL, '谢谢家长', '2025-12-25 22:46:03', '2025-12-25 22:45:32', '2025-12-25 22:46:03', 0);

-- ----------------------------
-- Table structure for care_plan
-- ----------------------------
DROP TABLE IF EXISTS `care_plan`;
CREATE TABLE `care_plan`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `institution_id` bigint NOT NULL COMMENT '机构ID',
  `baby_id` bigint NOT NULL COMMENT '宝宝ID',
  `nanny_id` bigint NULL DEFAULT NULL COMMENT '指定保姆ID',
  `appointment_id` bigint NULL DEFAULT NULL COMMENT '关联预约ID',
  `plan_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '计划名称',
  `plan_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '计划内容',
  `start_date` date NOT NULL COMMENT '开始日期',
  `end_date` date NULL DEFAULT NULL COMMENT '结束日期',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-待执行，1-进行中，2-已完成，3-已取消）',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE,
  INDEX `idx_baby_id`(`baby_id` ASC) USING BTREE,
  INDEX `idx_nanny_id`(`nanny_id` ASC) USING BTREE,
  INDEX `idx_appointment_id`(`appointment_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '护理计划表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of care_plan
-- ----------------------------
INSERT INTO `care_plan` VALUES (1, 1, 2, 1, 2, '张小美的护理计划', '洗脚', '2025-12-24', '2026-01-13', 1, '2025-12-23 21:59:16', '2025-12-24 22:07:53', 0);
INSERT INTO `care_plan` VALUES (2, 1, 1, 1, 3, '张小明的护理计划', '早教', '2025-12-24', '2025-12-24', 2, '2025-12-24 21:30:34', '2025-12-24 23:20:02', 0);
INSERT INTO `care_plan` VALUES (3, 1, 2, 1, 4, '张小美的护理计划', '带宝宝做五三数学题', '2025-12-25', '2025-12-25', 2, '2025-12-25 22:41:06', '2025-12-25 22:44:00', 0);

-- ----------------------------
-- Table structure for care_plan_checkin
-- ----------------------------
DROP TABLE IF EXISTS `care_plan_checkin`;
CREATE TABLE `care_plan_checkin`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `appointment_id` bigint NOT NULL COMMENT '关联预约ID',
  `nanny_id` bigint NOT NULL COMMENT '保姆ID',
  `checkin_type` tinyint NOT NULL COMMENT '签到类型（1-签到，2-签退）',
  `checkin_time` datetime NOT NULL COMMENT '签到时间',
  `checkin_longitude` decimal(10, 7) NULL DEFAULT NULL COMMENT '签到经度',
  `checkin_latitude` decimal(10, 7) NULL DEFAULT NULL COMMENT '签到纬度',
  `checkin_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '签到地址（反解析）',
  `distance` int NULL DEFAULT NULL COMMENT '距离服务地址的距离（米）',
  `is_in_range` tinyint NULL DEFAULT 0 COMMENT '是否在范围内（0-否，1-是）',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_nanny_id`(`nanny_id` ASC) USING BTREE,
  INDEX `idx_appointment_id`(`appointment_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '护理计划签到表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of care_plan_checkin
-- ----------------------------
INSERT INTO `care_plan_checkin` VALUES (1, 3, 1, 1, '2025-12-24 21:26:01', 112.9880170, 28.2249890, '', 365, 1, NULL, '2025-12-24 21:26:01');
INSERT INTO `care_plan_checkin` VALUES (2, 3, 1, 2, '2025-12-24 22:13:48', 112.9880160, 28.2249880, '', 364, 1, NULL, '2025-12-24 22:13:48');
INSERT INTO `care_plan_checkin` VALUES (3, 3, 1, 1, '2025-12-24 22:14:02', 112.9880160, 28.2249880, '', 364, 1, NULL, '2025-12-24 22:14:02');
INSERT INTO `care_plan_checkin` VALUES (4, 3, 1, 2, '2025-12-24 22:19:29', 112.9844910, 28.2239420, '', 0, 1, NULL, '2025-12-24 22:19:29');
INSERT INTO `care_plan_checkin` VALUES (5, 3, 1, 1, '2025-12-24 22:20:25', 112.9844910, 28.2239420, '', 0, 1, NULL, '2025-12-24 22:20:25');
INSERT INTO `care_plan_checkin` VALUES (6, 3, 1, 2, '2025-12-24 22:20:36', 112.9844910, 28.2239420, '', 0, 1, NULL, '2025-12-24 22:20:36');
INSERT INTO `care_plan_checkin` VALUES (7, 3, 1, 1, '2025-12-24 23:18:52', 112.9880170, 28.2249890, '', 365, 1, NULL, '2025-12-24 23:18:52');
INSERT INTO `care_plan_checkin` VALUES (8, 3, 1, 2, '2025-12-24 23:20:02', 112.9880170, 28.2249890, '', 365, 1, NULL, '2025-12-24 23:20:02');
INSERT INTO `care_plan_checkin` VALUES (9, 3, 1, 1, '2025-12-25 22:41:32', 112.9880170, 28.2249890, '', 365, 1, NULL, '2025-12-25 22:41:32');
INSERT INTO `care_plan_checkin` VALUES (10, 4, 1, 1, '2025-12-25 22:42:15', 112.9880170, 28.2249890, '', 365, 1, NULL, '2025-12-25 22:42:15');
INSERT INTO `care_plan_checkin` VALUES (11, 4, 1, 2, '2025-12-25 22:44:00', 112.9844540, 28.2238520, '', 11, 1, NULL, '2025-12-25 22:44:00');

-- ----------------------------
-- Table structure for care_record
-- ----------------------------
DROP TABLE IF EXISTS `care_record`;
CREATE TABLE `care_record`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `care_plan_id` bigint NULL DEFAULT NULL COMMENT '护理计划ID',
  `baby_id` bigint NOT NULL COMMENT '宝宝ID',
  `nanny_id` bigint NOT NULL COMMENT '保姆ID',
  `record_date` date NOT NULL COMMENT '记录日期',
  `record_time` time NULL DEFAULT NULL COMMENT '记录时间',
  `care_type` tinyint NULL DEFAULT 1 COMMENT '护理类型（1-喂养，2-洗护，3-哄睡，4-早教，5-其他）',
  `care_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '护理内容',
  `images` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '图片（JSON数组）',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_care_plan_id`(`care_plan_id` ASC) USING BTREE,
  INDEX `idx_baby_id`(`baby_id` ASC) USING BTREE,
  INDEX `idx_nanny_id`(`nanny_id` ASC) USING BTREE,
  INDEX `idx_record_date`(`record_date` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '护理记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of care_record
-- ----------------------------
INSERT INTO `care_record` VALUES (1, 2, 1, 1, '2025-12-24', '22:07:08', 1, '做了萝卜辅食', NULL, '宝宝很爱吃', '2025-12-24 22:07:08', '2025-12-24 22:07:08', 0);
INSERT INTO `care_record` VALUES (2, 2, 1, 1, '2025-12-24', '23:19:13', 2, '洗了头发', NULL, '宝宝很乖', '2025-12-24 23:19:13', '2025-12-24 23:19:13', 0);
INSERT INTO `care_record` VALUES (3, 3, 2, 1, '2025-12-25', '22:42:44', 4, '带宝宝学了微积分，宝宝可高兴了', NULL, '宝宝很聪明', '2025-12-25 22:42:44', '2025-12-25 22:42:44', 0);

-- ----------------------------
-- Table structure for cart
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `parent_id` bigint NOT NULL COMMENT '家长ID',
  `product_id` bigint NOT NULL COMMENT '商品ID',
  `quantity` int NULL DEFAULT 1 COMMENT '数量',
  `selected` tinyint NULL DEFAULT 1 COMMENT '是否选中（0-否，1-是）',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_parent_id`(`parent_id` ASC) USING BTREE,
  INDEX `idx_product_id`(`product_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '购物车表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of cart
-- ----------------------------

-- ----------------------------
-- Table structure for finance_record
-- ----------------------------
DROP TABLE IF EXISTS `finance_record`;
CREATE TABLE `finance_record`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `institution_id` bigint NOT NULL COMMENT '机构ID',
  `record_type` tinyint NOT NULL COMMENT '记录类型（1-收入，2-支出）',
  `amount` decimal(10, 2) NOT NULL COMMENT '金额',
  `source_type` tinyint NULL DEFAULT NULL COMMENT '来源类型（1-订单收入，2-服务收入，3-物资采购，4-人员工资，5-其他）',
  `source_id` bigint NULL DEFAULT NULL COMMENT '来源ID',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `record_date` date NOT NULL COMMENT '记录日期',
  `operator_id` bigint NULL DEFAULT NULL COMMENT '操作人ID',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE,
  INDEX `idx_record_date`(`record_date` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '财务记录表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of finance_record
-- ----------------------------
INSERT INTO `finance_record` VALUES (1, 1, 1, 49.00, 1, NULL, '', '2025-12-24', NULL, '2025-12-25 22:07:46', '2025-12-25 22:07:46', 0);
INSERT INTO `finance_record` VALUES (2, 1, 1, 49.00, 1, NULL, '``1`', '2025-12-25', NULL, '2025-12-25 22:49:18', '2025-12-25 22:49:18', 0);

-- ----------------------------
-- Table structure for institution
-- ----------------------------
DROP TABLE IF EXISTS `institution`;
CREATE TABLE `institution`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码（MD5加密）',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '机构名称',
  `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '机构LOGO',
  `contact_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系人姓名',
  `contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '联系电话',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `license_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '营业执照号',
  `license_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '营业执照图片',
  `introduction` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '机构简介',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-禁用，1-正常，2-待审核）',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_username`(`username` ASC) USING BTREE,
  UNIQUE INDEX `uk_contact_phone`(`contact_phone` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 29 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '机构表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of institution
-- ----------------------------
INSERT INTO `institution` VALUES (1, 'aixintianshi', '40a1dd73691b03e7bb35c12aab584d75', '爱心天使', '/upload/2025/12/25/7cdf59f6f10c45f4aec167ebdd434968.png', '张三', '15643600767', 'aixintianshi@example.com', '23232111211212', '/upload/2025/12/25/a969bff6d23d44499aa21897e670df6a.png', '11111111111111111111111', 1, '2025-12-23 19:37:38', '2025-12-25 22:34:59', 0);
INSERT INTO `institution` VALUES (2, 'jinpai_yuesao', '40a1dd73691b03e7bb35c12aab584d75', '金牌月嫂家政服务', 'https://picsum.photos/seed/inst3/200/200', '王经理', '13800138002', 'jinpai@example.com', '91110000MA01234569', 'https://picsum.photos/seed/license3/800/600', '专注高端母婴护理服务，所有月嫂均持有专业资格证书，经过严格培训。提供24小时贴心服务，让新手妈妈安心坐月子。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (3, 'beibei_jia', '40a1dd73691b03e7bb35c12aab584d75', '贝贝佳母婴护理', 'https://picsum.photos/seed/inst4/200/200', '刘女士', '13800138003', 'beibeijia@example.com', '91110000MA01234570', 'https://picsum.photos/seed/license4/800/600', '致力于为新生儿家庭提供专业、温馨的护理服务。团队成员均有5年以上从业经验，注重科学育儿理念的传递。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (4, 'xinyue_huisuo', '40a1dd73691b03e7bb35c12aab584d75', '馨月母婴会所', 'https://picsum.photos/seed/inst5/200/200', '陈经理', '13800138004', 'xinyue@example.com', '91110000MA01234571', 'https://picsum.photos/seed/license5/800/600', '高端月子会所，提供星级酒店式月子护理服务。配备专业医护团队、营养师、产后康复师，一站式解决产后护理需求。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (5, 'nuanxin_jizheng', '40a1dd73691b03e7bb35c12aab584d75', '暖心家政服务中心', 'https://picsum.photos/seed/inst6/200/200', '赵主管', '13800138005', 'nuanxin@example.com', '91110000MA01234572', 'https://picsum.photos/seed/license6/800/600', '提供全方位家政服务，包括月嫂、育婴师、保姆等。所有员工经过专业培训，服务态度好，深受客户好评。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (6, 'youbei_muying', '40a1dd73691b03e7bb35c12aab584d75', '优贝母婴护理', 'https://picsum.photos/seed/inst7/200/200', '孙经理', '13800138006', 'youbei@example.com', '91110000MA01234573', 'https://picsum.photos/seed/license7/800/600', '专业母婴护理机构，提供月嫂、育婴师、催乳师等专业服务。注重服务质量，定期回访跟踪，确保客户满意度。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (7, 'tianshi_zhijia', '40a1dd73691b03e7bb35c12aab584d75', '天使之家母婴中心', 'https://picsum.photos/seed/inst8/200/200', '周女士', '13800138007', 'tianshizhijia@example.com', '91110000MA01234574', 'https://picsum.photos/seed/license8/800/600', '专注于新生儿护理和产妇护理，拥有丰富的临床经验。提供个性化服务方案，满足不同家庭的需求。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (8, 'xinxin_muying', '40a1dd73691b03e7bb35c12aab584d75', '欣欣母婴服务', 'https://picsum.photos/seed/inst9/200/200', '吴经理', '13800138008', 'xinxin@example.com', '91110000MA01234575', 'https://picsum.photos/seed/license9/800/600', '新成立的母婴服务机构，团队成员均来自知名月子中心，具有丰富的实战经验。', 2, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (9, 'baobao_leyuan', '40a1dd73691b03e7bb35c12aab584d75', '宝宝乐园护理中心', 'https://picsum.photos/seed/inst10/200/200', '郑主任', '13800138009', 'baobaoleyuan@example.com', '91110000MA01234576', 'https://picsum.photos/seed/license10/800/600', '集月子护理、早教启蒙于一体的综合性母婴服务机构。环境温馨舒适，设施完善，深受家长信赖。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (10, 'kangxin_muying', '40a1dd73691b03e7bb35c12aab584d75', '康馨母婴', 'https://picsum.photos/seed/inst11/200/200', '马经理', '13800138010', 'kangxin@example.com', '91110000MA01234577', 'https://picsum.photos/seed/license11/800/600', '专业母婴健康护理服务，提供产后恢复、新生儿护理等服务。', 2, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (11, 'mami_baobei', '40a1dd73691b03e7bb35c12aab584d75', '妈咪宝贝家政', 'https://picsum.photos/seed/inst12/200/200', '朱女士', '13800138011', 'mamibaobei@example.com', '91110000MA01234578', 'https://picsum.photos/seed/license12/800/600', '拥有多年家政服务经验，月嫂服务细致周到，深受客户好评。提供免费试用期，满意后再签约。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (12, 'xingfu_jiayuan', '40a1dd73691b03e7bb35c12aab584d75', '幸福家园母婴护理', 'https://picsum.photos/seed/inst13/200/200', '何主管', '13800138012', 'xingfujiayuan@example.com', '91110000MA01234579', 'https://picsum.photos/seed/license13/800/600', '致力于为每个家庭带来幸福和温暖。专业的护理团队，贴心的服务态度，让产后生活更轻松。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (13, 'xiaotianshi', '40a1dd73691b03e7bb35c12aab584d75', '小天使母婴中心', 'https://picsum.photos/seed/inst14/200/200', '许经理', '13800138013', 'xiaotianshi@example.com', '91110000MA01234580', 'https://picsum.photos/seed/license14/800/600', '专注0-3岁婴幼儿护理服务，提供科学的育儿指导和专业的护理技能。服务人员经验丰富，耐心细致。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);
INSERT INTO `institution` VALUES (14, 'huixin_muying', '40a1dd73691b03e7bb35c12aab584d75', '慧心母婴服务', 'https://picsum.photos/seed/inst15/200/200', '黄女士', '13800138014', 'huixin@example.com', '91110000MA01234581', 'https://picsum.photos/seed/license15/800/600', '以专业和爱心为服务理念，为新生儿家庭提供全方位的护理服务。定期组织培训，不断提升服务质量。', 1, '2025-12-23 19:37:38', '2025-12-23 19:37:38', 0);

-- ----------------------------
-- Table structure for inventory
-- ----------------------------
DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `institution_id` bigint NOT NULL COMMENT '机构ID',
  `product_id` bigint NOT NULL COMMENT '商品ID',
  `operate_type` tinyint NOT NULL COMMENT '操作类型（1-入库，2-出库，3-盘点）',
  `quantity` int NOT NULL COMMENT '操作数量',
  `before_stock` int NULL DEFAULT 0 COMMENT '操作前库存',
  `after_stock` int NULL DEFAULT 0 COMMENT '操作后库存',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `operator_id` bigint NULL DEFAULT NULL COMMENT '操作人ID',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE,
  INDEX `idx_product_id`(`product_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 100 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '库存表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inventory
-- ----------------------------
INSERT INTO `inventory` VALUES (1, 1, 1, 1, 300, 0, 300, '首次入库', 1, '2025-01-05 09:00:00');
INSERT INTO `inventory` VALUES (2, 1, 1, 2, 50, 300, 250, '订单出库', 1, '2025-01-15 14:30:00');
INSERT INTO `inventory` VALUES (3, 1, 1, 2, 30, 250, 220, '订单出库', 1, '2025-02-10 10:20:00');
INSERT INTO `inventory` VALUES (4, 1, 1, 3, 0, 220, 200, '月度盘点调整', 1, '2025-03-01 18:00:00');
INSERT INTO `inventory` VALUES (5, 1, 2, 1, 200, 0, 200, '首次入库', 1, '2025-01-05 09:10:00');
INSERT INTO `inventory` VALUES (6, 1, 2, 2, 30, 200, 170, '订单出库', 1, '2025-01-20 11:00:00');
INSERT INTO `inventory` VALUES (7, 1, 2, 2, 20, 170, 150, '订单出库', 1, '2025-02-15 15:45:00');
INSERT INTO `inventory` VALUES (8, 1, 3, 1, 150, 0, 150, '首次入库', 1, '2025-01-05 09:20:00');
INSERT INTO `inventory` VALUES (9, 1, 3, 2, 50, 150, 100, '订单出库', 1, '2025-02-01 09:30:00');
INSERT INTO `inventory` VALUES (10, 1, 4, 1, 400, 0, 400, '首次入库', 1, '2025-01-06 09:00:00');
INSERT INTO `inventory` VALUES (11, 1, 4, 2, 80, 400, 320, '订单出库', 1, '2025-01-25 13:20:00');
INSERT INTO `inventory` VALUES (12, 1, 4, 2, 20, 320, 300, '订单出库', 1, '2025-02-20 16:10:00');
INSERT INTO `inventory` VALUES (13, 1, 5, 1, 600, 0, 600, '首次入库', 1, '2025-01-06 09:10:00');
INSERT INTO `inventory` VALUES (14, 1, 5, 2, 100, 600, 500, '订单出库', 1, '2025-02-05 10:00:00');
INSERT INTO `inventory` VALUES (15, 1, 6, 1, 500, 0, 500, '首次入库', 1, '2025-01-06 09:20:00');
INSERT INTO `inventory` VALUES (16, 1, 6, 2, 100, 500, 400, '订单出库', 1, '2025-02-10 11:30:00');
INSERT INTO `inventory` VALUES (17, 1, 7, 1, 250, 0, 250, '首次入库', 1, '2025-01-06 09:30:00');
INSERT INTO `inventory` VALUES (18, 1, 7, 2, 50, 250, 200, '订单出库', 1, '2025-02-15 14:00:00');
INSERT INTO `inventory` VALUES (19, 1, 8, 1, 400, 0, 400, '首次入库', 1, '2025-01-07 09:00:00');
INSERT INTO `inventory` VALUES (20, 1, 8, 2, 80, 400, 320, '订单出库', 1, '2025-01-28 10:30:00');
INSERT INTO `inventory` VALUES (21, 1, 8, 2, 20, 320, 300, '订单出库', 1, '2025-02-18 15:20:00');
INSERT INTO `inventory` VALUES (22, 1, 9, 1, 500, 0, 500, '首次入库', 1, '2025-01-07 09:10:00');
INSERT INTO `inventory` VALUES (23, 1, 9, 2, 100, 500, 400, '订单出库', 1, '2025-02-08 11:00:00');
INSERT INTO `inventory` VALUES (24, 1, 10, 1, 400, 0, 400, '首次入库', 1, '2025-01-07 09:20:00');
INSERT INTO `inventory` VALUES (25, 1, 10, 2, 50, 400, 350, '订单出库', 1, '2025-02-12 09:45:00');
INSERT INTO `inventory` VALUES (26, 1, 11, 1, 250, 0, 250, '首次入库', 1, '2025-01-07 09:30:00');
INSERT INTO `inventory` VALUES (27, 1, 11, 2, 50, 250, 200, '订单出库', 1, '2025-02-20 14:30:00');
INSERT INTO `inventory` VALUES (28, 1, 12, 1, 800, 0, 800, '首次入库', 1, '2025-01-07 09:40:00');
INSERT INTO `inventory` VALUES (29, 1, 12, 2, 150, 800, 650, '订单出库', 1, '2025-02-01 10:00:00');
INSERT INTO `inventory` VALUES (30, 1, 12, 2, 50, 650, 600, '订单出库', 1, '2025-02-25 16:00:00');
INSERT INTO `inventory` VALUES (31, 1, 13, 1, 500, 0, 500, '首次入库', 1, '2025-01-08 09:00:00');
INSERT INTO `inventory` VALUES (32, 1, 13, 2, 100, 500, 400, '订单出库', 1, '2025-02-10 11:20:00');
INSERT INTO `inventory` VALUES (33, 1, 14, 1, 300, 0, 300, '首次入库', 1, '2025-01-08 09:10:00');
INSERT INTO `inventory` VALUES (34, 1, 14, 2, 50, 300, 250, '订单出库', 1, '2025-02-15 13:40:00');
INSERT INTO `inventory` VALUES (35, 1, 15, 1, 350, 0, 350, '首次入库', 1, '2025-01-08 09:20:00');
INSERT INTO `inventory` VALUES (36, 1, 15, 2, 50, 350, 300, '订单出库', 1, '2025-02-18 10:30:00');
INSERT INTO `inventory` VALUES (37, 1, 16, 1, 400, 0, 400, '首次入库', 1, '2025-01-08 09:30:00');
INSERT INTO `inventory` VALUES (38, 1, 16, 2, 50, 400, 350, '订单出库', 1, '2025-02-20 15:00:00');
INSERT INTO `inventory` VALUES (39, 1, 17, 1, 200, 0, 200, '首次入库', 1, '2025-01-08 09:40:00');
INSERT INTO `inventory` VALUES (40, 1, 17, 2, 50, 200, 150, '订单出库', 1, '2025-02-22 11:00:00');
INSERT INTO `inventory` VALUES (41, 1, 18, 1, 250, 0, 250, '首次入库', 1, '2025-01-09 09:00:00');
INSERT INTO `inventory` VALUES (42, 1, 18, 2, 50, 250, 200, '订单出库', 1, '2025-02-10 14:20:00');
INSERT INTO `inventory` VALUES (43, 1, 19, 1, 200, 0, 200, '首次入库', 1, '2025-01-09 09:10:00');
INSERT INTO `inventory` VALUES (44, 1, 19, 2, 50, 200, 150, '订单出库', 1, '2025-02-15 10:00:00');
INSERT INTO `inventory` VALUES (45, 1, 20, 1, 60, 0, 60, '首次入库', 1, '2025-01-09 09:20:00');
INSERT INTO `inventory` VALUES (46, 1, 20, 2, 10, 60, 50, '订单出库', 1, '2025-02-20 16:30:00');
INSERT INTO `inventory` VALUES (47, 1, 21, 1, 120, 0, 120, '首次入库', 1, '2025-01-09 09:30:00');
INSERT INTO `inventory` VALUES (48, 1, 21, 2, 20, 120, 100, '订单出库', 1, '2025-02-18 11:45:00');
INSERT INTO `inventory` VALUES (49, 1, 22, 1, 250, 0, 250, '首次入库', 1, '2025-01-09 09:40:00');
INSERT INTO `inventory` VALUES (50, 1, 22, 2, 50, 250, 200, '订单出库', 1, '2025-02-22 14:00:00');
INSERT INTO `inventory` VALUES (51, 1, 23, 1, 350, 0, 350, '首次入库', 1, '2025-01-10 09:00:00');
INSERT INTO `inventory` VALUES (52, 1, 23, 2, 50, 350, 300, '订单出库', 1, '2025-02-12 10:30:00');
INSERT INTO `inventory` VALUES (53, 1, 24, 1, 450, 0, 450, '首次入库', 1, '2025-01-10 09:10:00');
INSERT INTO `inventory` VALUES (54, 1, 24, 2, 50, 450, 400, '订单出库', 1, '2025-02-15 15:20:00');
INSERT INTO `inventory` VALUES (55, 1, 25, 1, 180, 0, 180, '首次入库', 1, '2025-01-10 09:20:00');
INSERT INTO `inventory` VALUES (56, 1, 25, 2, 30, 180, 150, '订单出库', 1, '2025-02-18 09:00:00');
INSERT INTO `inventory` VALUES (57, 1, 26, 1, 250, 0, 250, '首次入库', 1, '2025-01-10 09:30:00');
INSERT INTO `inventory` VALUES (58, 1, 26, 2, 50, 250, 200, '订单出库', 1, '2025-02-20 11:30:00');
INSERT INTO `inventory` VALUES (59, 1, 27, 1, 400, 0, 400, '首次入库', 1, '2025-01-11 09:00:00');
INSERT INTO `inventory` VALUES (60, 1, 27, 2, 100, 400, 300, '订单出库', 1, '2025-02-08 14:00:00');
INSERT INTO `inventory` VALUES (61, 1, 28, 1, 300, 0, 300, '首次入库', 1, '2025-01-11 09:10:00');
INSERT INTO `inventory` VALUES (62, 1, 28, 2, 50, 300, 250, '订单出库', 1, '2025-02-12 10:00:00');
INSERT INTO `inventory` VALUES (63, 1, 29, 1, 500, 0, 500, '首次入库', 1, '2025-01-11 09:20:00');
INSERT INTO `inventory` VALUES (64, 1, 29, 2, 100, 500, 400, '订单出库', 1, '2025-02-15 16:30:00');
INSERT INTO `inventory` VALUES (65, 1, 30, 1, 120, 0, 120, '首次入库', 1, '2025-01-11 09:30:00');
INSERT INTO `inventory` VALUES (66, 1, 30, 2, 20, 120, 100, '订单出库', 1, '2025-02-18 13:00:00');
INSERT INTO `inventory` VALUES (67, 1, 31, 1, 180, 0, 180, '首次入库', 1, '2025-01-11 09:40:00');
INSERT INTO `inventory` VALUES (68, 1, 31, 2, 30, 180, 150, '订单出库', 1, '2025-02-20 10:20:00');
INSERT INTO `inventory` VALUES (69, 1, 32, 1, 40, 0, 40, '首次入库', 1, '2025-01-12 09:00:00');
INSERT INTO `inventory` VALUES (70, 1, 32, 2, 10, 40, 30, '订单出库', 1, '2025-02-22 15:00:00');
INSERT INTO `inventory` VALUES (71, 1, 33, 1, 60, 0, 60, '首次入库', 1, '2025-01-12 09:10:00');
INSERT INTO `inventory` VALUES (72, 1, 33, 2, 10, 60, 50, '订单出库', 1, '2025-02-25 11:00:00');
INSERT INTO `inventory` VALUES (73, 1, 34, 1, 100, 0, 100, '首次入库', 1, '2025-01-12 09:20:00');
INSERT INTO `inventory` VALUES (74, 1, 34, 2, 20, 100, 80, '订单出库', 1, '2025-02-28 14:30:00');
INSERT INTO `inventory` VALUES (75, 1, 35, 1, 120, 0, 120, '首次入库', 1, '2025-01-12 09:30:00');
INSERT INTO `inventory` VALUES (76, 1, 35, 2, 20, 120, 100, '订单出库', 1, '2025-03-01 10:00:00');
INSERT INTO `inventory` VALUES (77, 1, 36, 1, 600, 0, 600, '首次入库', 1, '2025-01-13 09:00:00');
INSERT INTO `inventory` VALUES (78, 1, 36, 2, 100, 600, 500, '订单出库', 1, '2025-02-10 09:30:00');
INSERT INTO `inventory` VALUES (79, 1, 37, 1, 120, 0, 120, '首次入库', 1, '2025-01-13 09:10:00');
INSERT INTO `inventory` VALUES (80, 1, 37, 2, 20, 120, 100, '订单出库', 1, '2025-02-15 11:20:00');
INSERT INTO `inventory` VALUES (81, 1, 38, 1, 700, 0, 700, '首次入库', 1, '2025-01-13 09:20:00');
INSERT INTO `inventory` VALUES (82, 1, 38, 2, 100, 700, 600, '订单出库', 1, '2025-02-18 14:00:00');
INSERT INTO `inventory` VALUES (83, 1, 39, 1, 450, 0, 450, '首次入库', 1, '2025-01-13 09:30:00');
INSERT INTO `inventory` VALUES (84, 1, 39, 2, 50, 450, 400, '订单出库', 1, '2025-02-20 16:00:00');
INSERT INTO `inventory` VALUES (85, 1, 40, 1, 180, 0, 180, '首次入库', 1, '2025-01-13 09:40:00');
INSERT INTO `inventory` VALUES (86, 1, 40, 2, 30, 180, 150, '订单出库', 1, '2025-02-22 10:30:00');
INSERT INTO `inventory` VALUES (87, 1, 5, 1, 200, 500, 700, '热销补货', 1, '2025-03-05 09:00:00');
INSERT INTO `inventory` VALUES (88, 1, 5, 2, 200, 700, 500, '订单出库', 1, '2025-03-15 14:00:00');
INSERT INTO `inventory` VALUES (89, 1, 12, 1, 300, 600, 900, '热销补货', 1, '2025-03-08 10:00:00');
INSERT INTO `inventory` VALUES (90, 1, 12, 2, 300, 900, 600, '订单出库', 1, '2025-03-20 11:30:00');
INSERT INTO `inventory` VALUES (91, 1, 8, 1, 150, 300, 450, '热销补货', 1, '2025-03-10 09:30:00');
INSERT INTO `inventory` VALUES (92, 1, 8, 2, 150, 450, 300, '订单出库', 1, '2025-03-25 15:00:00');
INSERT INTO `inventory` VALUES (93, 1, 1, 3, 0, 200, 200, '季度盘点-库存正常', 1, '2025-03-31 18:00:00');
INSERT INTO `inventory` VALUES (94, 1, 8, 3, 0, 300, 300, '季度盘点-库存正常', 1, '2025-03-31 18:05:00');
INSERT INTO `inventory` VALUES (95, 1, 13, 3, 0, 400, 400, '季度盘点-库存正常', 1, '2025-03-31 18:10:00');
INSERT INTO `inventory` VALUES (96, 1, 27, 3, 0, 300, 300, '季度盘点-库存正常', 1, '2025-03-31 18:15:00');
INSERT INTO `inventory` VALUES (97, 1, 36, 3, 0, 500, 500, '季度盘点-库存正常', 1, '2025-03-31 18:20:00');
INSERT INTO `inventory` VALUES (98, 1, 1, 1, 2, 200, 202, '进货两件', 1, '2025-12-25 20:19:59');
INSERT INTO `inventory` VALUES (99, 1, 13, 2, 1, 398, 397, '卖出去了', 1, '2025-12-25 22:48:46');

-- ----------------------------
-- Table structure for message
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sender_type` tinyint NOT NULL COMMENT '发送人类型（1-家长，2-保姆，3-机构，4-管理员）',
  `sender_id` bigint NOT NULL COMMENT '发送人ID',
  `receiver_type` tinyint NOT NULL COMMENT '接收人类型（1-家长，2-保姆，3-机构，4-管理员）',
  `receiver_id` bigint NOT NULL COMMENT '接收人ID',
  `msg_type` tinyint NULL DEFAULT 1 COMMENT '消息类型（1-系统消息，2-护理提醒，3-留言反馈）',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '消息标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '消息内容',
  `is_read` tinyint NULL DEFAULT 0 COMMENT '是否已读（0-未读，1-已读）',
  `read_time` datetime NULL DEFAULT NULL COMMENT '阅读时间',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_sender`(`sender_type` ASC, `sender_id` ASC) USING BTREE,
  INDEX `idx_receiver`(`receiver_type` ASC, `receiver_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '消息/留言表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES (1, 4, 1, 1, 1, 3, NULL, '您的反馈已收到', 1, '2025-12-25 20:59:25', '2025-12-25 20:41:56', 0);
INSERT INTO `message` VALUES (2, 4, 1, 3, 1, 3, NULL, '再接再厉', 1, '2025-12-25 20:49:13', '2025-12-25 20:43:50', 0);
INSERT INTO `message` VALUES (3, 1, 1, 4, 1, 3, NULL, '再接再厉', 0, NULL, '2025-12-25 20:59:46', 0);
INSERT INTO `message` VALUES (4, 1, 1, 4, 1, 3, NULL, '你好', 0, NULL, '2025-12-25 21:07:31', 0);
INSERT INTO `message` VALUES (5, 1, 1, 4, 1, 3, NULL, '11', 0, NULL, '2025-12-25 21:24:12', 0);
INSERT INTO `message` VALUES (6, 3, 1, 1, 1, 3, NULL, '您好', 1, '2025-12-25 21:25:57', '2025-12-25 21:24:37', 0);
INSERT INTO `message` VALUES (7, 1, 1, 3, 1, 3, NULL, '好的', 0, NULL, '2025-12-25 21:32:16', 0);
INSERT INTO `message` VALUES (8, 3, 1, 1, 1, 3, NULL, '111', 0, NULL, '2025-12-25 21:32:30', 0);
INSERT INTO `message` VALUES (9, 3, 1, 1, 1, 3, NULL, '111', 0, NULL, '2025-12-25 21:34:18', 0);
INSERT INTO `message` VALUES (10, 3, 1, 4, 1, 3, NULL, '111', 0, NULL, '2025-12-25 21:34:28', 0);
INSERT INTO `message` VALUES (11, 3, 1, 1, 1, 3, NULL, '11', 0, NULL, '2025-12-25 21:47:43', 0);
INSERT INTO `message` VALUES (12, 3, 1, 1, 1, 3, NULL, '11', 0, NULL, '2025-12-25 21:52:38', 0);
INSERT INTO `message` VALUES (13, 4, 1, 2, 1, 3, NULL, '加油', 0, NULL, '2025-12-25 22:22:33', 0);
INSERT INTO `message` VALUES (14, 1, 1, 2, 1, 3, NULL, '加油', 0, NULL, '2025-12-25 22:23:02', 0);
INSERT INTO `message` VALUES (15, 2, 1, 1, 1, 3, NULL, '好的', 0, NULL, '2025-12-25 22:23:17', 0);
INSERT INTO `message` VALUES (16, 3, 1, 1, 1, 3, NULL, '您对我们的服务还满意吗', 0, NULL, '2025-12-25 22:52:31', 0);
INSERT INTO `message` VALUES (17, 1, 1, 3, 1, 3, NULL, '挺满意', 0, NULL, '2025-12-25 22:52:47', 0);
INSERT INTO `message` VALUES (18, 2, 1, 1, 1, 3, NULL, '亲记得给好评哦', 0, NULL, '2025-12-25 22:53:12', 0);
INSERT INTO `message` VALUES (19, 1, 1, 2, 1, 3, NULL, '没问题老铁', 0, NULL, '2025-12-25 22:53:29', 0);

-- ----------------------------
-- Table structure for nanny
-- ----------------------------
DROP TABLE IF EXISTS `nanny`;
CREATE TABLE `nanny`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `institution_id` bigint NULL DEFAULT NULL COMMENT '所属机构ID',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码（MD5加密）',
  `real_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '真实姓名',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '手机号',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像URL',
  `gender` tinyint NULL DEFAULT 2 COMMENT '性别（0-未知，1-男，2-女）',
  `id_card` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '身份证号',
  `birth_date` date NULL DEFAULT NULL COMMENT '出生日期',
  `work_years` int NULL DEFAULT 0 COMMENT '工作年限',
  `certificate` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '资格证书（JSON数组）',
  `introduction` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '个人简介',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-禁用，1-正常）',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_username`(`username` ASC) USING BTREE,
  UNIQUE INDEX `uk_phone`(`phone` ASC) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 45 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '保姆表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of nanny
-- ----------------------------
INSERT INTO `nanny` VALUES (1, 1, 'ldx', '40a1dd73691b03e7bb35c12aab584d75', '张三', '15643600767', '3367748835@qq.com', '/upload/2025/12/23/818e393111054fb39a571c0d015b4c99.jpg', 1, '220183200304243456', NULL, 10, '[\"http://localhost:8080/upload/2025/12/23/81288c05a10846bba7a47beff3ee5913.jpg\",\"http://localhost:8080/upload/2025/12/23/4d22eb5d57da41dd9d21e824b978b468.jpg\"]', '唱跳rap', 1, '2025-12-23 20:33:32', '2025-12-23 20:47:33', 0);
INSERT INTO `nanny` VALUES (2, 1, 'nanny_zhangmei', '40a1dd73691b03e7bb35c12aab584d75', '张美', '15900001001', 'zhangmei@example.com', 'https://picsum.photos/seed/nanny1/200/200', 2, '110101198501011234', '1985-01-01', 10, '[\"高级月嫂证\",\"母婴护理师\"]', '从事月嫂工作10年，照顾过200多个宝宝，经验丰富，耐心细致。擅长新生儿护理、产妇护理、月子餐制作。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (3, 1, 'nanny_liulan', '40a1dd73691b03e7bb35c12aab584d75', '刘兰', '15900001002', 'liulan@example.com', 'https://picsum.photos/seed/nanny2/200/200', 2, '110101198802022345', '1988-02-02', 7, '[\"中级月嫂证\",\"育婴师\"]', '持有多项专业证书，爱心耐心，善于与宝宝互动。精通新生儿按摩、早教启蒙。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (4, 1, 'nanny_wangfang', '40a1dd73691b03e7bb35c12aab584d75', '王芳', '15900001003', 'wangfang@example.com', 'https://picsum.photos/seed/nanny3/200/200', 2, '110101199003033456', '1990-03-03', 5, '[\"初级月嫂证\"]', '年轻有活力，学习能力强，服务态度好。擅长新生儿日常护理。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (5, 1, 'nanny_chenxiu', '40a1dd73691b03e7bb35c12aab584d75', '陈秀', '15900001004', 'chenxiu@example.com', 'https://picsum.photos/seed/nanny4/200/200', 2, '110101198306044567', '1983-06-04', 12, '[\"高级月嫂证\",\"催乳师证\",\"营养师证\"]', '资深月嫂，有丰富的护理经验和专业技能。特别擅长催乳、产后康复指导。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (6, 1, 'nanny_sunli', '40a1dd73691b03e7bb35c12aab584d75', '孙丽', '15900001005', 'sunli@example.com', 'https://picsum.photos/seed/nanny5/200/200', 2, '110101199205055678', '1992-05-05', 3, '[\"初级月嫂证\"]', '新入职保姆，工作认真负责，塩能充分配合客户需求。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (7, 2, 'nanny_zhaoli', '40a1dd73691b03e7bb35c12aab584d75', '赵丽', '15900002001', 'zhaoli@example.com', 'https://picsum.photos/seed/nanny6/200/200', 2, '110101198707066789', '1987-07-06', 8, '[\"高级月嫂证\",\"高级育婴师\"]', '专业月嫂，擅长新生儿护理和产妇护理，获得众多客户好评。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (8, 2, 'nanny_qianhua', '40a1dd73691b03e7bb35c12aab584d75', '钱华', '15900002002', 'qianhua@example.com', 'https://picsum.photos/seed/nanny7/200/200', 2, '110101199108077890', '1991-08-07', 4, '[\"中级月嫂证\"]', '温柔耐心，喜欢小孩子，能够耗心照馗每一个宝宝。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (9, 2, 'nanny_zhoujing', '40a1dd73691b03e7bb35c12aab584d75', '周静', '15900002003', 'zhoujing@example.com', 'https://picsum.photos/seed/nanny8/200/200', 2, '110101198909088901', '1989-09-08', 6, '[\"高级月嫂证\",\"小儿按摩师\"]', '有丰富的小儿按摩经验，能够帮助宝宝健康成长。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (10, 2, 'nanny_wuying', '40a1dd73691b03e7bb35c12aab584d75', '吴英', '15900002004', 'wuying@example.com', 'https://picsum.photos/seed/nanny9/200/200', 2, '110101198410099012', '1984-10-09', 11, '[\"高级月嫂证\",\"催乳师证\",\"产后康复师\"]', '资深月嫂，丰富的产后康复和催乳经验，深受客户信赖。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (11, 3, 'nanny_zhengmin', '40a1dd73691b03e7bb35c12aab584d75', '郑敏', '15900003001', 'zhengmin@example.com', 'https://picsum.photos/seed/nanny10/200/200', 2, '110101198611100123', '1986-11-10', 9, '[\"金牌月嫂证\",\"高级育婴师\"]', '金牌月嫂，服务过许多高端客户，专业技能过硬，服务态度一流。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (12, 3, 'nanny_wangqiang', '40a1dd73691b03e7bb35c12aab584d75', '王强', '15900003002', 'wangqiang@example.com', 'https://picsum.photos/seed/nanny11/200/200', 1, '110101199012111234', '1990-12-11', 5, '[\"中级月嫂证\",\"营养师证\"]', '男性月嫂，体力好，擅长月子餐制作和家居整理。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (13, 3, 'nanny_linxia', '40a1dd73691b03e7bb35c12aab584d75', '林夏', '15900003003', 'linxia@example.com', 'https://picsum.photos/seed/nanny12/200/200', 2, '110101198801122345', '1988-01-12', 7, '[\"高级月嫂证\"]', '专业月嫂，有爱心、耐心，擅长与客户沟通，服务体验好。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (14, 3, 'nanny_huangling', '40a1dd73691b03e7bb35c12aab584d75', '黄灵', '15900003004', 'huangling@example.com', 'https://picsum.photos/seed/nanny13/200/200', 2, '110101199302133456', '1993-02-13', 2, '[\"初级月嫂证\"]', '年轻月嫂，充满热情，学习能力强，爱学习新知识。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (15, 4, 'nanny_yangmei', '40a1dd73691b03e7bb35c12aab584d75', '杨梅', '15900004001', 'yangmei@example.com', 'https://picsum.photos/seed/nanny14/200/200', 2, '110101198503144567', '1985-03-14', 10, '[\"高级月嫂证\",\"高级育婴师\",\"早教指导师\"]', '资深月嫂，精通早教启蒙，能够科学引导宝宝成长。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (16, 4, 'nanny_xumei', '40a1dd73691b03e7bb35c12aab584d75', '徐美', '15900004002', 'xumei@example.com', 'https://picsum.photos/seed/nanny15/200/200', 2, '110101199004155678', '1990-04-15', 5, '[\"中级月嫂证\"]', '温柔耐心，善于观察宝宝需求，细心周到。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (17, 4, 'nanny_sunxue', '40a1dd73691b03e7bb35c12aab584d75', '孙雪', '15900004003', 'sunxue@example.com', 'https://picsum.photos/seed/nanny16/200/200', 2, '110101198705166789', '1987-05-16', 8, '[\"高级月嫂证\",\"小儿按摩师\"]', '专业小儿按摩师，能帮助宝宝健康成长，增强免疫力。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (18, 5, 'nanny_lijuan', '40a1dd73691b03e7bb35c12aab584d75', '李娟', '15900005001', 'lijuan@example.com', 'https://picsum.photos/seed/nanny17/200/200', 2, '110101198206177890', '1982-06-17', 13, '[\"金牌月嫂证\",\"高级育婴师\",\"催乳师\",\"产后康复师\"]', '星级月嫂，服务过多位明星客户，专业技能卓越，服务体验极佳。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (19, 5, 'nanny_zhangying', '40a1dd73691b03e7bb35c12aab584d75', '张缱', '15900005002', 'zhangying@example.com', 'https://picsum.photos/seed/nanny18/200/200', 2, '110101198407188901', '1984-07-18', 11, '[\"金牌月嫂证\",\"营养师证\",\"心理咨询师\"]', '专业营养月嫂，擅长制作各类月子餐，并提供产后心理疏导。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (20, 5, 'nanny_wangli', '40a1dd73691b03e7bb35c12aab584d75', '王丽', '15900005003', 'wangli@example.com', 'https://picsum.photos/seed/nanny19/200/200', 2, '110101198608199012', '1986-08-19', 9, '[\"高级月嫂证\",\"早教指导师\"]', '精通早教启蒙，能够科学引导宝宝智力发育。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (21, 5, 'nanny_chenjing', '40a1dd73691b03e7bb35c12aab584d75', '陈静', '15900005004', 'chenjing@example.com', 'https://picsum.photos/seed/nanny20/200/200', 2, '110101198809200123', '1988-09-20', 7, '[\"高级月嫂证\",\"催乳师证\"]', '专业催乳师，帮助新手妈妈顺利实现母乳喂养。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (22, 5, 'nanny_liuyan', '40a1dd73691b03e7bb35c12aab584d75', '刘艳', '15900005005', 'liuyan@example.com', 'https://picsum.photos/seed/nanny21/200/200', 2, '110101199010211234', '1990-10-21', 5, '[\"中级月嫂证\"]', '年轻有活力，善于学习，服务态度维热情。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (23, 6, 'nanny_hefang', '40a1dd73691b03e7bb35c12aab584d75', '何芳', '15900006001', 'hefang@example.com', 'https://picsum.photos/seed/nanny22/200/200', 2, '110101198711222345', '1987-11-22', 8, '[\"高级月嫂证\"]', '服务态度好，工作认真负责，获得客户一致好评。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (24, 6, 'nanny_gaoyan', '40a1dd73691b03e7bb35c12aab584d75', '高燕', '15900006002', 'gaoyan@example.com', 'https://picsum.photos/seed/nanny23/200/200', 2, '110101199112233456', '1991-12-23', 4, '[\"中级月嫂证\"]', '耐心细致，善于照馗宝宝，能够给家庭带来温暖。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (25, 6, 'nanny_pengxia', '40a1dd73691b03e7bb35c12aab584d75', '彭霞', '15900006003', 'pengxia@example.com', 'https://picsum.photos/seed/nanny24/200/200', 2, '110101198501244567', '1985-01-24', 10, '[\"高级月嫂证\",\"催乳师证\"]', '资深月嫂，丰富的护理经验，特别擅长催乳服务。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (26, 7, 'nanny_tangmin', '40a1dd73691b03e7bb35c12aab584d75', '唐敏', '15900007001', 'tangmin@example.com', 'https://picsum.photos/seed/nanny25/200/200', 2, '110101198602255678', '1986-02-25', 9, '[\"高级月嫂证\",\"高级育婴师\"]', '专业月嫂，擅长新生儿护理和早教启蒙。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (27, 7, 'nanny_fanli', '40a1dd73691b03e7bb35c12aab584d75', '范丽', '15900007002', 'fanli@example.com', 'https://picsum.photos/seed/nanny26/200/200', 2, '110101199203266789', '1992-03-26', 3, '[\"初级月嫂证\"]', '新人月嫂，工作热情高，学习能力强。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (28, 7, 'nanny_shenyun', '40a1dd73691b03e7bb35c12aab584d75', '沈蕀', '15900007003', 'shenyun@example.com', 'https://picsum.photos/seed/nanny27/200/200', 2, '110101198904277890', '1989-04-27', 6, '[\"中级月嫂证\",\"小儿按摩师\"]', '有丰富的小儿按摩经验，帮助宝宝健康成长。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (29, 8, 'nanny_dongmei', '40a1dd73691b03e7bb35c12aab584d75', '董梅', '15900008001', 'dongmei@example.com', 'https://picsum.photos/seed/nanny28/200/200', 2, '110101198405288901', '1984-05-28', 11, '[\"高级月嫂证\",\"产后康复师\"]', '资深月嫂，精通产后康复，帮助新妈妈快速恢复。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (30, 8, 'nanny_lujing', '40a1dd73691b03e7bb35c12aab584d75', '陆静', '15900008002', 'lujing@example.com', 'https://picsum.photos/seed/nanny29/200/200', 2, '110101199006299012', '1990-06-29', 5, '[\"中级月嫂证\"]', '温柔耐心，细心照馗宝宝，服务体验好。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (31, 8, 'nanny_xueying', '40a1dd73691b03e7bb35c12aab584d75', '薛英', '15900008003', 'xueying@example.com', 'https://picsum.photos/seed/nanny30/200/200', 2, '110101198707300123', '1987-07-30', 8, '[\"高级月嫂证\",\"营养师证\"]', '专业营养月嫂，擅长制作各类营养月子餐。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (32, 10, 'nanny_caihong', '40a1dd73691b03e7bb35c12aab584d75', '蔡红', '15900010001', 'caihong@example.com', 'https://picsum.photos/seed/nanny31/200/200', 2, '110101198808011234', '1988-08-01', 7, '[\"高级月嫂证\",\"早教指导师\"]', '精通早教启蒙，能够帮助宝宝全面发展。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (33, 10, 'nanny_maoli', '40a1dd73691b03e7bb35c12aab584d75', '毛丽', '15900010002', 'maoli@example.com', 'https://picsum.photos/seed/nanny32/200/200', 2, '110101199309022345', '1993-09-02', 2, '[\"初级月嫂证\"]', '新人月嫂，工作认真，学习能力强。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (34, 10, 'nanny_leixue', '40a1dd73691b03e7bb35c12aab584d75', '雷雪', '15900010003', 'leixue@example.com', 'https://picsum.photos/seed/nanny33/200/200', 2, '110101198610033456', '1986-10-03', 9, '[\"高级月嫂证\",\"高级育婴师\"]', '专业月嫂，经验丰富，服务质量有保障。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (35, 12, 'nanny_jiangwei', '40a1dd73691b03e7bb35c12aab584d75', '姜威', '15900012001', 'jiangwei@example.com', 'https://picsum.photos/seed/nanny34/200/200', 2, '110101198511044567', '1985-11-04', 10, '[\"高级月嫂证\",\"催乳师证\"]', '资深月嫂，专业催乳师，服务体验佳。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (36, 12, 'nanny_yuxia', '40a1dd73691b03e7bb35c12aab584d75', '于霞', '15900012002', 'yuxia@example.com', 'https://picsum.photos/seed/nanny35/200/200', 2, '110101199112055678', '1991-12-05', 4, '[\"中级月嫂证\"]', '服务态度好，耐心细心，获得客户认可。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (37, 13, 'nanny_bailin', '40a1dd73691b03e7bb35c12aab584d75', '白林', '15900013001', 'bailin@example.com', 'https://picsum.photos/seed/nanny36/200/200', 2, '110101198612066789', '1986-12-06', 9, '[\"高级月嫂证\",\"高级育婴师\"]', '专业月嫂，服务热情周到，获得多次客户表扬。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (38, 13, 'nanny_shili', '40a1dd73691b03e7bb35c12aab584d75', '史丽', '15900013002', 'shili@example.com', 'https://picsum.photos/seed/nanny37/200/200', 2, '110101199001077890', '1990-01-07', 5, '[\"中级月嫂证\"]', '爱心满满，照颗宝宝细心，服务质量高。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (39, 13, 'nanny_jiaxue', '40a1dd73691b03e7bb35c12aab584d75', '贾雪', '15900013003', 'jiaxue@example.com', 'https://picsum.photos/seed/nanny38/200/200', 2, '110101198802088901', '1988-02-08', 7, '[\"高级月嫂证\"]', '专业月嫂，服务细致，耐心体贴。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (40, 14, 'nanny_qiuyan', '40a1dd73691b03e7bb35c12aab584d75', '邱燕', '15900014001', 'qiuyan@example.com', 'https://picsum.photos/seed/nanny39/200/200', 2, '110101198703099012', '1987-03-09', 8, '[\"高级月嫂证\",\"早教指导师\"]', '精通0-3岁婴幼儿护理和早教启蒙。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (41, 14, 'nanny_wangxin', '40a1dd73691b03e7bb35c12aab584d75', '王欣', '15900014002', 'wangxin@example.com', 'https://picsum.photos/seed/nanny40/200/200', 2, '110101199204100123', '1992-04-10', 3, '[\"初级月嫂证\"]', '新人月嫂，工作热情，善于学习。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (42, 15, 'nanny_zhangqin', '40a1dd73691b03e7bb35c12aab584d75', '张琴', '15900015001', 'zhangqin@example.com', 'https://picsum.photos/seed/nanny41/200/200', 2, '110101198604111234', '1986-04-11', 9, '[\"高级月嫂证\",\"高级育婴师\"]', '专业月嫂，服务态度好，技能过硬。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (43, 15, 'nanny_chenyu', '40a1dd73691b03e7bb35c12aab584d75', '陈玉', '15900015002', 'chenyu@example.com', 'https://picsum.photos/seed/nanny42/200/200', 2, '110101199005122345', '1990-05-12', 5, '[\"中级月嫂证\"]', '温柔耐心，善于与客户沟通。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);
INSERT INTO `nanny` VALUES (44, 15, 'nanny_liufang', '40a1dd73691b03e7bb35c12aab584d75', '刘芳', '15900015003', 'liufang@example.com', 'https://picsum.photos/seed/nanny43/200/200', 2, '110101198806133456', '1988-06-13', 7, '[\"高级月嫂证\",\"催乳师证\"]', '专业催乳师，帮助新妈妈顺利母乳喂养。', 1, '2025-12-25 21:04:17', '2025-12-25 21:04:17', 0);

-- ----------------------------
-- Table structure for nanny_attendance
-- ----------------------------
DROP TABLE IF EXISTS `nanny_attendance`;
CREATE TABLE `nanny_attendance`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `institution_id` bigint NOT NULL COMMENT '机构ID',
  `nanny_id` bigint NOT NULL COMMENT '保姆ID',
  `schedule_id` bigint NULL DEFAULT NULL COMMENT '排班ID',
  `attendance_date` date NOT NULL COMMENT '考勤日期',
  `check_in_time` datetime NULL DEFAULT NULL COMMENT '签到时间',
  `check_out_time` datetime NULL DEFAULT NULL COMMENT '签退时间',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-缺勤，1-正常，2-迟到，3-早退，4-请假）',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE,
  INDEX `idx_nanny_id`(`nanny_id` ASC) USING BTREE,
  INDEX `idx_attendance_date`(`attendance_date` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '保姆考勤表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of nanny_attendance
-- ----------------------------

-- ----------------------------
-- Table structure for nanny_schedule
-- ----------------------------
DROP TABLE IF EXISTS `nanny_schedule`;
CREATE TABLE `nanny_schedule`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `institution_id` bigint NOT NULL COMMENT '机构ID',
  `nanny_id` bigint NOT NULL COMMENT '保姆ID',
  `schedule_date` date NOT NULL COMMENT '排班日期',
  `shift_type` tinyint NULL DEFAULT 1 COMMENT '班次类型（1-早班，2-中班，3-晚班，4-全天）',
  `start_time` time NULL DEFAULT NULL COMMENT '上班时间',
  `end_time` time NULL DEFAULT NULL COMMENT '下班时间',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-取消，1-正常，2-调班）',
  `swap_target_nanny_id` bigint NULL DEFAULT NULL COMMENT '调班目标保姆ID',
  `swap_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '调班原因',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE,
  INDEX `idx_nanny_id`(`nanny_id` ASC) USING BTREE,
  INDEX `idx_schedule_date`(`schedule_date` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 79 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '保姆排班表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of nanny_schedule
-- ----------------------------
INSERT INTO `nanny_schedule` VALUES (1, 1, 2, '2025-12-26', 1, '08:00:00', '12:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:20:43', '2025-12-25 21:20:43', 0);
INSERT INTO `nanny_schedule` VALUES (2, 1, 3, '2025-12-25', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (3, 1, 4, '2025-12-25', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (4, 1, 5, '2025-12-25', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (5, 1, 1, '2025-12-25', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (6, 1, 3, '2025-12-26', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (7, 1, 4, '2025-12-26', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (8, 1, 5, '2025-12-26', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (9, 1, 1, '2025-12-26', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (10, 1, 3, '2025-12-29', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (11, 1, 4, '2025-12-29', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (12, 1, 5, '2025-12-29', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (13, 1, 1, '2025-12-29', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (14, 1, 3, '2025-12-30', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (15, 1, 4, '2025-12-30', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (16, 1, 5, '2025-12-30', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (17, 1, 1, '2025-12-30', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (18, 1, 3, '2025-12-31', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (19, 1, 4, '2025-12-31', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (20, 1, 5, '2025-12-31', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (21, 1, 1, '2025-12-31', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (22, 1, 3, '2026-01-01', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (23, 1, 4, '2026-01-01', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (24, 1, 5, '2026-01-01', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (25, 1, 1, '2026-01-01', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (26, 1, 3, '2026-01-02', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (27, 1, 4, '2026-01-02', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (28, 1, 5, '2026-01-02', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (29, 1, 1, '2026-01-02', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (30, 1, 3, '2026-01-05', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (31, 1, 4, '2026-01-05', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (32, 1, 5, '2026-01-05', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (33, 1, 1, '2026-01-05', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (34, 1, 3, '2026-01-06', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (35, 1, 4, '2026-01-06', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (36, 1, 5, '2026-01-06', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:27', '2025-12-25 21:21:27', 0);
INSERT INTO `nanny_schedule` VALUES (37, 1, 1, '2026-01-06', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (38, 1, 3, '2026-01-07', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (39, 1, 4, '2026-01-07', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (40, 1, 5, '2026-01-07', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (41, 1, 1, '2026-01-07', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (42, 1, 3, '2026-01-08', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (43, 1, 4, '2026-01-08', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (44, 1, 5, '2026-01-08', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (45, 1, 1, '2026-01-08', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (46, 1, 3, '2026-01-09', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (47, 1, 4, '2026-01-09', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (48, 1, 5, '2026-01-09', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (49, 1, 1, '2026-01-09', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (50, 1, 3, '2026-01-12', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (51, 1, 4, '2026-01-12', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (52, 1, 5, '2026-01-12', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (53, 1, 1, '2026-01-12', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (54, 1, 3, '2026-01-13', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (55, 1, 4, '2026-01-13', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (56, 1, 5, '2026-01-13', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (57, 1, 1, '2026-01-13', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (58, 1, 3, '2026-01-14', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (59, 1, 4, '2026-01-14', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (60, 1, 5, '2026-01-14', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (61, 1, 1, '2026-01-14', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (62, 1, 3, '2026-01-15', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (63, 1, 4, '2026-01-15', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (64, 1, 5, '2026-01-15', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (65, 1, 1, '2026-01-15', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (66, 1, 3, '2026-01-16', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (67, 1, 4, '2026-01-16', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (68, 1, 5, '2026-01-16', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (69, 1, 1, '2026-01-16', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (70, 1, 3, '2026-01-19', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (71, 1, 4, '2026-01-19', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (72, 1, 5, '2026-01-19', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (73, 1, 1, '2026-01-19', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (74, 1, 3, '2026-01-20', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (75, 1, 4, '2026-01-20', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (76, 1, 5, '2026-01-20', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (77, 1, 1, '2026-01-20', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 21:21:28', '2025-12-25 21:21:28', 0);
INSERT INTO `nanny_schedule` VALUES (78, 1, 1, '2026-02-12', 4, '08:00:00', '22:00:00', 1, NULL, NULL, '加油', '2025-12-25 22:55:22', '2025-12-25 22:55:22', 0);

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公告标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '公告内容',
  `type` tinyint NULL DEFAULT 1 COMMENT '公告类型（1-系统公告，2-活动通知，3-其他）',
  `target_type` tinyint NULL DEFAULT 0 COMMENT '目标类型（0-全部，1-家长，2-保姆，3-机构）',
  `publisher_id` bigint NULL DEFAULT NULL COMMENT '发布人ID',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-草稿，1-已发布，2-已下线）',
  `publish_time` datetime NULL DEFAULT NULL COMMENT '发布时间',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '系统公告表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (1, '悦芽婴护管理系统正式上线公告', '尊敬的用户：\r\n\r\n悦芽婴护管理系统已于2025年12月正式上线！\r\n\r\n本系统是一个为母婴护理行业提供数字化解决方案的综合平台，涵盖护理服务管理、人员调度、婴幼儿成长记录、在线商城等功能。\r\n\r\n主要功能包括：\r\n1. 婴幼儿信息管理与健康档案\r\n2. 护理计划制定与执行跟踪\r\n3. 保姆排班与考勤管理\r\n4. 在线预约服务\r\n5. 母婴商城购物\r\n6. 消息通知与互动\r\n\r\n感谢您的支持与信任！\r\n\r\n悦芽婴护团队\r\n2025年12月', 1, 0, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (2, '系统维护通知', '尊敬的用户：\r\n\r\n为了给您提供更好的服务体验，我们计划于2025年12月28日凌晨2:00-6:00进行系统维护升级。\r\n\r\n维护期间，系统将暂停服务，届时您将无法正常使用系统功能。\r\n\r\n请您提前做好相关安排，给您带来的不便敬请谅解。\r\n\r\n如有紧急问题，请联系客服热线：400-888-8888\r\n\r\n悦芽婴护团队', 1, 0, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (3, '隐私政策更新通知', '尊敬的用户：\r\n\r\n为了更好地保护您的个人信息安全，我们对《隐私政策》进行了更新。\r\n\r\n主要更新内容：\r\n1. 明确了个人信息的收集范围和使用目的\r\n2. 增加了数据安全保护措施说明\r\n3. 完善了用户权利保障条款\r\n4. 更新了第三方服务商信息\r\n\r\n更新后的隐私政策将于2025年1月1日起生效。\r\n\r\n如您继续使用我们的服务，即表示您同意接受更新后的隐私政策。\r\n\r\n如有疑问，请联系客服。\r\n\r\n悦芽婴护团队', 1, 0, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (4, '新年特惠活动 - 护理服务8折优惠', '亲爱的家长朋友们：\r\n\r\n新年将至，悦芽婴护特推出新年特惠活动！\r\n\r\n活动时间：2025年1月1日 - 2025年1月31日\r\n\r\n活动内容：\r\n🎁 护理服务全场8折优惠\r\n🎁 新用户首单立减50元\r\n🎁 推荐好友注册，双方各得100元优惠券\r\n🎁 累计消费满1000元，赠送精美婴儿礼盒一份\r\n\r\n参与方式：\r\n活动期间下单即可享受优惠，无需领取优惠券。\r\n\r\n温馨提示：\r\n- 优惠不可叠加使用\r\n- 最终解释权归悦芽婴护所有\r\n\r\n祝您新年快乐，阖家幸福！\r\n\r\n悦芽婴护团队', 2, 0, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (5, '母婴商城双12大促活动', '亲爱的用户：\r\n\r\n双12购物狂欢节来啦！悦芽婴护母婴商城为您准备了超值优惠！\r\n\r\n活动时间：2025年12月12日 00:00 - 2025年12月12日 23:59\r\n\r\n活动亮点：\r\n💰 全场商品满199减30\r\n💰 满399减80\r\n💰 满699减150\r\n💰 部分爆款商品低至5折\r\n\r\n热门商品推荐：\r\n- 婴儿纸尿裤 原价199元 活动价99元\r\n- 婴儿奶瓶套装 原价299元 活动价149元\r\n- 婴儿推车 原价1299元 活动价899元\r\n\r\n快来选购吧！数量有限，先到先得！\r\n\r\n悦芽婴护商城', 2, 1, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (6, '免费育儿讲座报名通知', '亲爱的家长朋友们：\r\n\r\n悦芽婴护将于2025年1月15日举办线上免费育儿讲座！\r\n\r\n讲座主题：《0-3岁婴幼儿科学喂养与护理》\r\n\r\n讲座内容：\r\n1. 母乳喂养的正确方法与常见问题\r\n2. 辅食添加的时机与注意事项\r\n3. 婴幼儿常见疾病的预防与护理\r\n4. 婴幼儿睡眠管理技巧\r\n5. 早期教育与亲子互动\r\n\r\n主讲嘉宾：\r\n张医生 - 三甲医院儿科主任医师，从业20年\r\n\r\n讲座时间：2025年1月15日 19:00-21:00\r\n讲座形式：线上直播（报名后发送直播链接）\r\n\r\n报名方式：\r\n在APP内\"活动\"页面点击报名即可\r\n\r\n名额有限，先报先得！\r\n\r\n悦芽婴护团队', 2, 1, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (7, '保姆培训通知', '各位保姆姐妹们：\r\n\r\n为提升服务质量，公司将于2025年1月举办专业技能培训。\r\n\r\n培训内容：\r\n1. 婴幼儿护理专业技能提升\r\n2. 急救知识与应急处理\r\n3. 沟通技巧与服务礼仪\r\n4. 职业道德与法律法规\r\n\r\n培训时间：\r\n第一期：2025年1月8日-10日\r\n第二期：2025年1月15日-17日\r\n\r\n培训地点：公司培训中心\r\n\r\n注意事项：\r\n- 培训期间提供免费午餐\r\n- 培训合格者颁发结业证书\r\n- 请提前与机构确认参加时间\r\n\r\n请各位保姆姐妹积极参加！\r\n\r\n悦芽婴护人力资源部', 1, 2, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (8, '保姆考勤制度更新通知', '各位保姆姐妹们：\r\n\r\n为规范服务管理，公司对考勤制度进行了更新，现通知如下：\r\n\r\n更新内容：\r\n1. 签到签退需在服务地址100米范围内完成\r\n2. 迟到超过15分钟需提前向机构报备\r\n3. 请假需提前24小时申请\r\n4. 连续旷工3天将自动解除合作关系\r\n\r\n考勤奖励：\r\n- 月度全勤奖励200元\r\n- 季度全勤奖励800元\r\n- 年度全勤奖励3000元\r\n\r\n新制度自2025年1月1日起执行。\r\n\r\n如有疑问，请联系所属机构。\r\n\r\n悦芽婴护人力资源部', 1, 2, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (9, '机构入驻优惠政策', '各位机构负责人：\r\n\r\n为扩大平台服务范围，悦芽婴护现推出机构入驻优惠政策！\r\n\r\n优惠内容：\r\n1. 2025年1月前入驻，免收首年平台服务费\r\n2. 入驻即送1000元推广基金\r\n3. 专属客户经理一对一服务\r\n4. 免费提供机构管理系统培训\r\n\r\n入驻条件：\r\n- 具有合法营业执照\r\n- 从事母婴护理相关业务\r\n- 服务人员持有相关资质证书\r\n\r\n入驻流程：\r\n1. 在线提交入驻申请\r\n2. 上传相关资质文件\r\n3. 平台审核（3个工作日内）\r\n4. 签署合作协议\r\n5. 开通机构账号\r\n\r\n欢迎各优质机构加入悦芽婴护平台！\r\n\r\n悦芽婴护商务部', 2, 3, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (10, '春节放假通知（草稿）', '尊敬的用户：\r\n\r\n根据国家法定节假日安排，现将2025年春节放假安排通知如下：\r\n\r\n放假时间：2025年1月28日（除夕）至2025年2月4日（初七），共8天\r\n\r\n节日期间服务安排：\r\n- 在线客服：正常服务\r\n- 护理服务：部分保姆可提供服务，请提前预约\r\n- 商城发货：2月5日起恢复正常发货\r\n\r\n祝大家新春快乐，万事如意！\r\n\r\n悦芽婴护团队', 1, 0, 1, 1, '2025-12-25 22:30:29', '2025-12-24 22:33:20', '2025-12-25 22:30:29', 0);
INSERT INTO `notice` VALUES (11, '双11活动已结束', '亲爱的用户：\r\n\r\n2024年双11活动已圆满结束！\r\n\r\n感谢大家的热情参与，活动期间共有超过10000名用户参与购物，销售额突破100万元！\r\n\r\n获奖名单将于3个工作日内公布，请关注后续通知。\r\n\r\n再次感谢您的支持！\r\n\r\n悦芽婴护团队', 2, 0, 1, 2, '2024-11-01 00:00:00', '2024-10-25 00:00:00', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (12, 'APP版本更新通知', '尊敬的用户：\r\n\r\n悦芽婴护APP已发布新版本（v2.0.0），建议您尽快更新！\r\n\r\n新版本更新内容：\r\n1. 全新UI界面设计，操作更便捷\r\n2. 新增消息中心功能\r\n3. 优化护理计划展示\r\n4. 修复已知问题，提升稳定性\r\n\r\n更新方式：\r\n- iOS用户：前往App Store搜索\"悦芽婴护\"更新\r\n- Android用户：前往应用商店或在APP内更新\r\n\r\n如遇问题，请联系客服。\r\n\r\n悦芽婴护技术团队', 1, 0, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (13, '用户服务协议更新通知', '尊敬的用户：\r\n\r\n为了更好地保障您的权益，我们对《用户服务协议》进行了更新。\r\n\r\n主要更新内容：\r\n1. 明确了服务内容和服务标准\r\n2. 完善了退款和售后政策\r\n3. 增加了争议解决机制\r\n4. 更新了知识产权条款\r\n\r\n更新后的协议将于2025年1月15日起生效。\r\n\r\n请您仔细阅读更新内容，如有疑问请联系客服。\r\n\r\n悦芽婴护法务部', 1, 0, 1, 1, '2025-12-24 22:33:20', '2025-12-24 22:33:20', '2025-12-24 22:33:20', 0);
INSERT INTO `notice` VALUES (14, '体检说明', '从明天开始，本站提供宝宝全身体检服务，请各位家长积极参与', 1, 1, 1, 1, '2025-12-25 22:50:36', '2025-12-25 22:50:33', '2025-12-25 22:50:36', 0);

-- ----------------------------
-- Table structure for order_item
-- ----------------------------
DROP TABLE IF EXISTS `order_item`;
CREATE TABLE `order_item`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `order_id` bigint NOT NULL COMMENT '订单ID',
  `product_id` bigint NOT NULL COMMENT '商品ID',
  `product_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '商品名称',
  `product_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '商品图片',
  `price` decimal(10, 2) NOT NULL COMMENT '商品单价',
  `quantity` int NOT NULL COMMENT '购买数量',
  `total_amount` decimal(10, 2) NOT NULL COMMENT '小计金额',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_order_id`(`order_id` ASC) USING BTREE,
  INDEX `idx_product_id`(`product_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '订单明细表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of order_item
-- ----------------------------
INSERT INTO `order_item` VALUES (1, 1, 13, '强生婴儿洗发沐浴露二合一', 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400', 49.90, 1, 49.90, '2025-12-24 23:24:04', '2025-12-24 23:24:04');
INSERT INTO `order_item` VALUES (2, 2, 13, '强生婴儿洗发沐浴露二合一', 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400', 49.90, 1, 49.90, '2025-12-25 22:47:20', '2025-12-25 22:47:20');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `order_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '订单编号',
  `parent_id` bigint NOT NULL COMMENT '家长ID',
  `institution_id` bigint NOT NULL COMMENT '机构ID',
  `total_amount` decimal(10, 2) NOT NULL COMMENT '订单总金额',
  `pay_amount` decimal(10, 2) NOT NULL COMMENT '实付金额',
  `freight_amount` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '运费',
  `discount_amount` decimal(10, 2) NULL DEFAULT 0.00 COMMENT '优惠金额',
  `pay_type` tinyint NULL DEFAULT NULL COMMENT '支付方式（1-微信，2-支付宝，3-余额）',
  `pay_time` datetime NULL DEFAULT NULL COMMENT '支付时间',
  `status` tinyint NULL DEFAULT 0 COMMENT '订单状态（0-待付款，1-待发货，2-待收货，3-已完成，4-已取消，5-已退款）',
  `receiver_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '收货人电话',
  `receiver_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '收货地址',
  `delivery_company` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '物流公司',
  `delivery_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '物流单号',
  `delivery_time` datetime NULL DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime NULL DEFAULT NULL COMMENT '收货时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '订单备注',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_order_no`(`order_no` ASC) USING BTREE,
  INDEX `idx_parent_id`(`parent_id` ASC) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '订单表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (1, 'ORD202512242324045547', 1, 1, 49.90, 49.90, 0.00, 0.00, 1, '2025-12-24 23:24:15', 2, '张三', '15743600767', '湖南省长沙市开福区', '顺丰速运', 'SF17172171111', '2025-12-24 23:42:50', NULL, '1111', '2025-12-24 23:24:04', '2025-12-24 23:42:50', 0);
INSERT INTO `orders` VALUES (2, 'ORD202512252247203098', 1, 1, 49.90, 49.90, 0.00, 0.00, 1, '2025-12-25 22:47:25', 3, '张三', '15743600767', '湖南省长沙市开福区', '中通快递', 'SF2774432234', '2025-12-25 22:47:52', '2025-12-25 22:47:58', '快点', '2025-12-25 22:47:20', '2025-12-25 22:47:58', 0);

-- ----------------------------
-- Table structure for parent
-- ----------------------------
DROP TABLE IF EXISTS `parent`;
CREATE TABLE `parent`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码（MD5加密）',
  `real_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '手机号',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像URL',
  `gender` tinyint NULL DEFAULT 0 COMMENT '性别（0-未知，1-男，2-女）',
  `id_card` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '身份证号',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-禁用，1-正常）',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_username`(`username` ASC) USING BTREE,
  UNIQUE INDEX `uk_phone`(`phone` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '家长表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of parent
-- ----------------------------
INSERT INTO `parent` VALUES (1, 'zhangwei', '9990990fc81ddaeccc2cb33e855a9aed', '张伟', '13800138001', 'zhangwei@example.com', '/upload/2025/12/23/72283a5b84914bff92c982fe71fe1f28.jpg', 1, '110101199001011234', 1, '2025-01-15 10:30:00', '2025-12-23 20:44:20', 0);
INSERT INTO `parent` VALUES (2, 'lina', '9990990fc81ddaeccc2cb33e855a9aed', '李娜', '13800138002', 'lina@example.com', 'https://img.zcool.cn/community/016a2057e4a6fa0000012e7ed75e83.png', 2, '110101199203152345', 1, '2025-02-20 14:20:00', '2025-12-23 19:37:49', 0);
INSERT INTO `parent` VALUES (3, 'wangfang', '9990990fc81ddaeccc2cb33e855a9aed', '王芳', '13800138003', 'wangfang@example.com', 'https://img.zcool.cn/community/01233056fb62fe32f875a9447ad5fe.jpg', 2, '310101198805203456', 1, '2025-03-10 09:15:00', '2025-12-23 19:37:49', 0);
INSERT INTO `parent` VALUES (4, 'liuyang', '9990990fc81ddaeccc2cb33e855a9aed', '刘洋', '13800138004', 'liuyang@example.com', 'https://img.zcool.cn/community/01cfd55d15a070a80120a8957d2d63.jpg', 1, '440101199106124567', 1, '2025-04-05 16:45:00', '2025-12-23 19:37:49', 0);
INSERT INTO `parent` VALUES (5, 'chenxia', '9990990fc81ddaeccc2cb33e855a9aed', '陈霞', '13800138005', 'chenxia@example.com', 'https://img.zcool.cn/community/01f8dc5b3d5e5da801216518a3c3d0.jpg', 2, '330101199308085678', 1, '2025-05-18 11:30:00', '2025-12-23 19:37:49', 0);
INSERT INTO `parent` VALUES (6, 'zhaoming', '9990990fc81ddaeccc2cb33e855a9aed', '赵明', '13800138006', 'zhaoming@example.com', 'https://img.zcool.cn/community/01d881577b40fa0000018c1b535e3f.jpg', 1, '510101198712156789', 1, '2025-06-22 08:00:00', '2025-12-23 19:37:49', 0);
INSERT INTO `parent` VALUES (7, 'sunli', '9990990fc81ddaeccc2cb33e855a9aed', '孙丽', '13800138007', 'sunli@example.com', 'https://img.zcool.cn/community/01a34a5b9b5c8fa801214168d6c0e6.jpg', 2, '320101199505206890', 1, '2025-07-08 13:20:00', '2025-12-23 19:37:49', 0);
INSERT INTO `parent` VALUES (8, 'zhoujun', '9990990fc81ddaeccc2cb33e855a9aed', '周军', '13800138008', 'zhoujun@example.com', 'https://img.zcool.cn/community/01233056fb630032f875a94479c9c8.jpg', 1, '420101198909127901', 1, '2025-08-12 15:40:00', '2025-12-23 19:37:49', 0);

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `institution_id` bigint NOT NULL COMMENT '所属机构ID',
  `category_id` bigint NOT NULL COMMENT '分类ID',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品名称',
  `cover_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '封面图片',
  `images` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '商品图片（JSON数组）',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '商品描述',
  `price` decimal(10, 2) NOT NULL COMMENT '销售价格',
  `original_price` decimal(10, 2) NULL DEFAULT NULL COMMENT '原价',
  `stock` int NULL DEFAULT 0 COMMENT '库存数量',
  `sales` int NULL DEFAULT 0 COMMENT '销量',
  `stock_alert` int NULL DEFAULT 10 COMMENT '库存预警值',
  `unit` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '单位',
  `sort` int NULL DEFAULT 0 COMMENT '排序',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-下架，1-上架）',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_institution_id`(`institution_id` ASC) USING BTREE,
  INDEX `idx_category_id`(`category_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 41 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '商品表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (1, 1, 101, '爱他美白金版婴幼儿奶粉1段', 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=400', '[\"https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?w=800\"]', '德国原装进口，适合0-6个月宝宝，富含DHA和ARA，促进大脑发育', 398.00, 658.00, 202, 1256, 10, '罐', 1, 1, '2025-12-24 21:02:32', '2025-12-25 20:19:59', 0);
INSERT INTO `product` VALUES (2, 1, 101, '美素佳儿金装婴儿奶粉2段', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400', '[\"https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800\"]', '荷兰原装进口，适合6-12个月宝宝，天然营养小分子，易消化吸收', 358.00, 398.00, 150, 892, 10, '罐', 2, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (3, 1, 102, '贝拉米有机婴儿奶粉3段', 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400', '[\"https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=800\"]', '澳洲有机认证，适合1-3岁宝宝，纯净有机奶源，无添加', 428.00, 498.00, 100, 567, 10, '罐', 3, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (4, 1, 104, '嘉宝有机米粉原味', 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=400', '[\"https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800\"]', '美国进口，适合6个月以上宝宝，有机大米制作，细腻易消化', 68.00, 78.00, 300, 2341, 10, '盒', 4, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (5, 1, 105, '小皮果泥苹果香蕉味', 'https://images.unsplash.com/photo-1622484211148-c9b4e0de4c3e?w=400', '[\"https://images.unsplash.com/photo-1622484211148-c9b4e0de4c3e?w=800\"]', '欧盟有机认证，适合6个月以上宝宝，100%纯水果制作', 15.90, 18.00, 500, 4521, 10, '袋', 5, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (6, 1, 107, '禧贝有机泡芙星星饼干', 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400', '[\"https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800\"]', '美国有机认证，适合8个月以上宝宝，入口即化，锻炼抓握能力', 35.00, 42.00, 400, 3256, 10, '罐', 6, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (7, 1, 108, '童年时光DHA鱼油软糖', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400', '[\"https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800\"]', '美国进口，适合1岁以上宝宝，深海鱼油提取，促进大脑发育', 168.00, 198.00, 200, 1892, 10, '瓶', 7, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (8, 1, 201, '花王妙而舒纸尿裤NB码', 'https://images.unsplash.com/photo-1522771930-78848d9293e8?w=400', '[\"https://images.unsplash.com/photo-1522771930-78848d9293e8?w=800\"]', '日本原装进口，适合0-5kg宝宝，超薄透气，柔软亲肤', 159.00, 189.00, 300, 5621, 10, '包', 1, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (9, 1, 201, '帮宝适一级帮纸尿裤S码', 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400', '[\"https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800\"]', '德国进口，适合4-8kg宝宝，12小时干爽，防侧漏设计', 139.00, 169.00, 400, 4892, 10, '包', 2, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (10, 1, 202, '好奇铂金装拉拉裤XL码', 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=400', '[\"https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=800\"]', '美国品牌，适合12-17kg宝宝，360度弹性腰围，穿脱方便', 149.00, 179.00, 350, 3567, 10, '包', 3, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (11, 1, 203, 'Moony游泳纸尿裤M码', 'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400', '[\"https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=800\"]', '日本进口，适合6-12kg宝宝，防水设计，游泳专用', 45.00, 55.00, 200, 1234, 10, '包', 4, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (12, 1, 205, '好孩子婴儿湿巾80抽', 'https://images.unsplash.com/photo-1584930435958-5b73c8bbdc6e?w=400', '[\"https://images.unsplash.com/photo-1584930435958-5b73c8bbdc6e?w=800\"]', '纯水配方，不含酒精香精，温和清洁，适合全身使用', 19.90, 25.00, 600, 8921, 10, '包', 5, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (13, 1, 301, '强生婴儿洗发沐浴露二合一', 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400', '[\"https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=800\"]', '无泪配方，温和清洁，适合新生儿使用，500ml大容量', 49.90, 59.00, 397, 6236, 10, '瓶', 1, 1, '2025-12-24 21:02:32', '2025-12-25 22:48:46', 0);
INSERT INTO `product` VALUES (14, 1, 302, '艾维诺婴儿燕麦润肤乳', 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400', '[\"https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800\"]', '美国皮肤科医生推荐，天然燕麦精华，24小时保湿', 89.00, 109.00, 250, 3456, 10, '瓶', 2, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (15, 1, 303, '贝亲婴儿牙刷牙膏套装', 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400', '[\"https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=800\"]', '适合1-3岁宝宝，软毛牙刷+可吞咽牙膏，草莓味', 45.00, 55.00, 300, 2345, 10, '套', 3, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (16, 1, 304, '保宁婴儿洗衣液', 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=400', '[\"https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=800\"]', '韩国进口，植物配方，去渍抗菌，温和不伤手', 59.00, 69.00, 350, 4567, 10, '瓶', 4, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (17, 1, 305, '小蜜蜂婴儿防晒霜SPF30', 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400', '[\"https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=800\"]', '美国进口，物理防晒，温和不刺激，适合6个月以上宝宝', 128.00, 158.00, 150, 1234, 10, '支', 5, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (18, 1, 401, '贝亲宽口径玻璃奶瓶240ml', 'https://images.unsplash.com/photo-1515488764276-beab7607c1e6?w=400', '[\"https://images.unsplash.com/photo-1515488764276-beab7607c1e6?w=800\"]', '日本进口，耐高温玻璃，仿母乳奶嘴，防胀气设计', 128.00, 158.00, 200, 3456, 10, '个', 1, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (19, 1, 401, 'Comotomo硅胶奶瓶250ml', 'https://images.unsplash.com/photo-1586339277861-b0b167f302e4?w=400', '[\"https://images.unsplash.com/photo-1586339277861-b0b167f302e4?w=800\"]', '美国进口，医用级硅胶，柔软仿真乳房设计，防摔', 198.00, 238.00, 150, 2345, 10, '个', 2, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (20, 1, 402, '美德乐丝韵翼电动吸奶器', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400', '[\"https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800\"]', '瑞士进口，双边电动，9档吸力调节，静音设计', 1299.00, 1599.00, 50, 567, 10, '台', 3, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (21, 1, 403, '小白熊暖奶消毒器二合一', 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=400', '[\"https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?w=800\"]', '恒温暖奶+蒸汽消毒，智能控温，大容量设计', 199.00, 259.00, 100, 1234, 10, '台', 4, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (22, 1, 405, 'bbox儿童学饮杯240ml', 'https://images.unsplash.com/photo-1515488764276-beab7607c1e6?w=400', '[\"https://images.unsplash.com/photo-1515488764276-beab7607c1e6?w=800\"]', '澳洲进口，重力球设计，任意角度都能喝，防漏', 89.00, 109.00, 200, 2567, 10, '个', 5, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (23, 1, 501, '英氏婴儿连体衣纯棉', 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=400', '[\"https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=800\"]', 'A类纯棉面料，柔软亲肤，适合0-6个月宝宝', 89.00, 119.00, 300, 2345, 10, '件', 1, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (24, 1, 502, '童泰婴儿内衣套装', 'https://images.unsplash.com/photo-1522771930-78848d9293e8?w=400', '[\"https://images.unsplash.com/photo-1522771930-78848d9293e8?w=800\"]', '精梳棉材质，无骨缝制，不刺激宝宝皮肤', 69.00, 89.00, 400, 3456, 10, '套', 2, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (25, 1, 504, '良良婴儿睡袋分腿式', 'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400', '[\"https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=800\"]', '六层纱布，透气保暖，可拆卸袖子，四季通用', 159.00, 199.00, 150, 1234, 10, '件', 3, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (26, 1, 505, '卡特兔婴儿学步鞋', 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400', '[\"https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800\"]', '软底防滑设计，透气网面，适合学步期宝宝', 128.00, 168.00, 200, 1567, 10, '双', 4, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (27, 1, 601, '曼哈顿球婴儿牙胶', 'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400', '[\"https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=800\"]', '美国进口，食品级硅胶，缓解出牙不适，锻炼抓握', 89.00, 109.00, 300, 4567, 10, '个', 1, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (28, 1, 602, 'Sassy布书认知套装', 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400', '[\"https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800\"]', '美国品牌，可水洗布书，色彩鲜艳，促进视觉发育', 68.00, 88.00, 250, 2345, 10, '套', 2, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (29, 1, 603, '费雪叠叠乐彩虹圈', 'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=400', '[\"https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=800\"]', '经典益智玩具，锻炼手眼协调，认识颜色大小', 59.00, 79.00, 400, 5678, 10, '套', 3, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (30, 1, 604, 'VTech音乐学习桌', 'https://images.unsplash.com/photo-1515488764276-beab7607c1e6?w=400', '[\"https://images.unsplash.com/photo-1515488764276-beab7607c1e6?w=800\"]', '多功能早教桌，音乐+灯光+游戏，促进多感官发育', 299.00, 399.00, 100, 1234, 10, '台', 4, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (31, 1, 606, '费雪婴儿健身架', 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=400', '[\"https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=800\"]', '钢琴健身架，躺着踢着玩，音乐灯光互动', 259.00, 329.00, 150, 2345, 10, '台', 5, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (32, 1, 701, 'Babyzen YOYO2婴儿推车', 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400', '[\"https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800\"]', '法国品牌，可登机折叠，轻便时尚，单手收车', 4999.00, 5999.00, 30, 234, 10, '台', 1, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (33, 1, 702, 'Cybex儿童安全座椅', 'https://images.unsplash.com/photo-1586339277861-b0b167f302e4?w=400', '[\"https://images.unsplash.com/photo-1586339277861-b0b167f302e4?w=800\"]', '德国品牌，ISOFIX接口，0-12岁可用，侧面防撞', 2599.00, 3299.00, 50, 345, 10, '台', 2, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (34, 1, 703, 'Ergobaby婴儿背带', 'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=400', '[\"https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=800\"]', '美国品牌，人体工学设计，护腰护脊，四季通用', 899.00, 1099.00, 80, 567, 10, '个', 3, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (35, 1, 704, 'Skip Hop妈咪包', 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400', '[\"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800\"]', '美国品牌，大容量多隔层，防水面料，时尚百搭', 399.00, 499.00, 100, 789, 10, '个', 4, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (36, 1, 801, '棒棒猪防撞角硅胶', 'https://images.unsplash.com/photo-1584930435958-5b73c8bbdc6e?w=400', '[\"https://images.unsplash.com/photo-1584930435958-5b73c8bbdc6e?w=800\"]', '食品级硅胶，柔软防撞，透明设计不影响美观', 25.00, 35.00, 500, 3456, 10, '包', 1, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (37, 1, 802, 'Regalo安全门栏', 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400', '[\"https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=800\"]', '美国品牌，免打孔安装，单手开关，宽度可调', 199.00, 259.00, 100, 1234, 10, '个', 2, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (38, 1, 803, '宝宝插座保护盖', 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400', '[\"https://images.unsplash.com/photo-1556228720-195a672e8a03?w=800\"]', '防触电设计，紧密贴合，不易被宝宝拔出', 15.00, 20.00, 600, 5678, 10, '包', 3, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (39, 1, 804, '儿童抽屉安全锁', 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=400', '[\"https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=800\"]', '免打孔设计，双重保险，防止宝宝夹手', 29.00, 39.00, 400, 2345, 10, '包', 4, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);
INSERT INTO `product` VALUES (40, 1, 805, '小米婴儿监控摄像头', 'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=400', '[\"https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=800\"]', '1080P高清，夜视功能，双向语音，手机远程查看', 199.00, 249.00, 150, 1567, 10, '台', 5, 1, '2025-12-24 21:02:32', '2025-12-24 21:02:32', 0);

-- ----------------------------
-- Table structure for product_category
-- ----------------------------
DROP TABLE IF EXISTS `product_category`;
CREATE TABLE `product_category`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `parent_id` bigint NULL DEFAULT 0 COMMENT '父分类ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '分类名称',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '分类图标',
  `sort` int NULL DEFAULT 0 COMMENT '排序',
  `status` tinyint NULL DEFAULT 1 COMMENT '状态（0-禁用，1-正常）',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_parent_id`(`parent_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 806 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '商品分类表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product_category
-- ----------------------------
INSERT INTO `product_category` VALUES (1, 0, '奶粉辅食', '/icons/category/milk.png', 1, 1, '2025-12-24 20:33:44', '2025-12-25 22:30:06', 0);
INSERT INTO `product_category` VALUES (2, 0, '纸尿裤', '/icons/category/diaper.png', 2, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (3, 0, '洗护用品', '/icons/category/wash.png', 3, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (4, 0, '喂养用品', '/icons/category/feeding.png', 4, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (5, 0, '服饰鞋帽', '/icons/category/clothes.png', 5, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (6, 0, '玩具早教', '/icons/category/toy.png', 6, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (7, 0, '出行装备', '/icons/category/travel.png', 7, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (8, 0, '安全防护', '/icons/category/safety.png', 8, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (101, 1, '婴幼儿奶粉', NULL, 1, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (102, 1, '有机奶粉', NULL, 2, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (103, 1, '特殊配方奶粉', NULL, 3, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (104, 1, '米粉米糊', NULL, 4, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (105, 1, '果泥菜泥', NULL, 5, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (106, 1, '肉泥鱼泥', NULL, 6, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (107, 1, '婴儿零食', NULL, 7, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (108, 1, '营养品', NULL, 8, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (201, 2, '纸尿裤', NULL, 1, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (202, 2, '拉拉裤', NULL, 2, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (203, 2, '游泳裤', NULL, 3, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (204, 2, '隔尿垫', NULL, 4, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (205, 2, '湿巾', NULL, 5, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (301, 3, '洗发沐浴', NULL, 1, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (302, 3, '润肤护肤', NULL, 2, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (303, 3, '口腔护理', NULL, 3, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (304, 3, '洗衣用品', NULL, 4, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (305, 3, '驱蚊防晒', NULL, 5, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (306, 3, '理发器具', NULL, 6, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (401, 4, '奶瓶奶嘴', NULL, 1, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (402, 4, '吸奶器', NULL, 2, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (403, 4, '暖奶消毒', NULL, 3, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (404, 4, '辅食工具', NULL, 4, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (405, 4, '餐具水杯', NULL, 5, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (406, 4, '围兜饭兜', NULL, 6, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (501, 5, '连体衣', NULL, 1, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (502, 5, '内衣套装', NULL, 2, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (503, 5, '外出服', NULL, 3, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (504, 5, '睡袋睡衣', NULL, 4, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (505, 5, '袜子鞋子', NULL, 5, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (506, 5, '帽子围巾', NULL, 6, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (601, 6, '摇铃牙胶', NULL, 1, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (602, 6, '布书卡片', NULL, 2, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (603, 6, '积木拼图', NULL, 3, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (604, 6, '音乐玩具', NULL, 4, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (605, 6, '益智玩具', NULL, 5, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (606, 6, '健身架', NULL, 6, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (701, 7, '婴儿推车', NULL, 1, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (702, 7, '安全座椅', NULL, 2, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (703, 7, '婴儿背带', NULL, 3, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (704, 7, '妈咪包', NULL, 4, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (705, 7, '遮阳防雨', NULL, 5, 1, '2025-12-24 20:33:44', '2025-12-24 20:33:44', 0);
INSERT INTO `product_category` VALUES (801, 8, '防撞角', NULL, 1, 1, '2025-12-24 20:33:45', '2025-12-24 20:33:45', 0);
INSERT INTO `product_category` VALUES (802, 8, '安全门栏', NULL, 2, 1, '2025-12-24 20:33:45', '2025-12-24 20:33:45', 0);
INSERT INTO `product_category` VALUES (803, 8, '插座保护', NULL, 3, 1, '2025-12-24 20:33:45', '2025-12-24 20:33:45', 0);
INSERT INTO `product_category` VALUES (804, 8, '抽屉锁', NULL, 4, 1, '2025-12-24 20:33:45', '2025-12-24 20:33:45', 0);
INSERT INTO `product_category` VALUES (805, 8, '监控设备', NULL, 5, 1, '2025-12-24 20:33:45', '2025-12-24 20:33:45', 0);

-- ----------------------------
-- Table structure for sys_user
-- ----------------------------
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user`  (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码（MD5加密）',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '昵称',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '手机号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '头像URL',
  `status` tinyint(1) NULL DEFAULT 1 COMMENT '状态（0-禁用，1-正常）',
  `create_time` datetime NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) NULL DEFAULT 0 COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `uk_username`(`username` ASC) USING BTREE,
  INDEX `idx_phone`(`phone` ASC) USING BTREE,
  INDEX `idx_email`(`email` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '用户表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sys_user
-- ----------------------------
INSERT INTO `sys_user` VALUES (1, 'admin', '40a1dd73691b03e7bb35c12aab584d75', '管理员', 'admin@example.com', '13800138000', NULL, 1, '2025-11-24 12:04:44', '2025-11-24 12:04:44', 0);
INSERT INTO `sys_user` VALUES (2, 'test', '40a1dd73691b03e7bb35c12aab584d75', '测试用户', 'test@example.com', '13800138001', NULL, 1, '2025-11-24 12:04:44', '2025-11-24 12:04:44', 0);

SET FOREIGN_KEY_CHECKS = 1;
