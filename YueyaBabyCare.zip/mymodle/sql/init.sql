-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS `yueya_care` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `yueya_care`;

-- 用户表
DROP TABLE IF EXISTS `sys_user`;
CREATE TABLE `sys_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码（MD5加密）',
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像URL',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态（0-禁用，1-正常）',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`) USING BTREE,
  KEY `idx_phone` (`phone`) USING BTREE,
  KEY `idx_email` (`email`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 插入测试数据
-- 密码为 123456，使用 MD5(123456 + mymodle_salt_2024) 加密
-- 使用 Md5Util.encryptWithSalt("123456") 生成
INSERT INTO `sys_user` (`username`, `password`, `nickname`, `email`, `phone`, `status`) VALUES
('admin', '40a1dd73691b03e7bb35c12aab584d75', '管理员', 'admin@example.com', '13800138000', 1),
('test', '40a1dd73691b03e7bb35c12aab584d75', '测试用户', 'test@example.com', '13800138001', 1);

-- 说明：
-- 密码为 123456（带盐值加密后的MD5）
-- 盐值：mymodle_salt_2024
-- 如需生成新密码，请运行 PasswordGenerator 工具类

-- 机构表
DROP TABLE IF EXISTS `institution`;
CREATE TABLE `institution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码（MD5加密）',
  `name` varchar(100) NOT NULL COMMENT '机构名称',
  `logo` varchar(255) DEFAULT NULL COMMENT '机构LOGO',
  `contact_name` varchar(50) DEFAULT NULL COMMENT '联系人姓名',
  `contact_phone` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `license_no` varchar(50) DEFAULT NULL COMMENT '营业执照号',
  `license_img` varchar(255) DEFAULT NULL COMMENT '营业执照图片',
  `introduction` text COMMENT '机构简介',
  `status` tinyint(1) DEFAULT '2' COMMENT '状态（0-禁用，1-正常，2-待审核）',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机构表';

-- 插入测试机构数据
INSERT INTO `institution` (`username`, `password`, `name`, `contact_name`, `contact_phone`, `email`, `license_no`, `introduction`, `status`) VALUES
('institution_test', '40a1dd73691b03e7bb35c12aab584d75', '悦芽母婴护理中心', '张经理', '13900139000', 'institution@example.com', '91110000MA01234567', '专业的母婴护理服务机构', 1);

-- 保姆表
DROP TABLE IF EXISTS `nanny`;
CREATE TABLE `nanny` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `institution_id` bigint(20) NOT NULL COMMENT '所属机构ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码（MD5加密）',
  `real_name` varchar(50) NOT NULL COMMENT '真实姓名',
  `phone` varchar(20) NOT NULL COMMENT '手机号',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像URL',
  `gender` tinyint(1) DEFAULT '0' COMMENT '性别（0-未知，1-男，2-女）',
  `id_card` varchar(18) DEFAULT NULL COMMENT '身份证号',
  `birth_date` date DEFAULT NULL COMMENT '出生日期',
  `work_years` int(11) DEFAULT '0' COMMENT '工作年限',
  `certificate` text COMMENT '资格证书（JSON数组）',
  `introduction` text COMMENT '个人简介',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态（0-禁用，1-正常）',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标志（0-未删除，1-已删除）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`) USING BTREE,
  UNIQUE KEY `uk_phone` (`phone`) USING BTREE,
  KEY `idx_institution_id` (`institution_id`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='保姆表';

-- 插入测试保姆数据
INSERT INTO `nanny` (`institution_id`, `username`, `password`, `real_name`, `phone`, `gender`, `work_years`, `introduction`, `status`) VALUES
(1, 'nanny_test', '40a1dd73691b03e7bb35c12aab584d75', '李阿姨', '13800138888', 2, 5, '拥有5年母婴护理经验，擅长新生儿护理', 1);

